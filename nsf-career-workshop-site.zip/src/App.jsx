import { useEffect, useMemo, useState } from "react";

const LAST_UPDATED = "May 14, 2026";

const fundingTrends = [
  {
    id: "nsf-ai",
    tag: "NSF Policy Signal",
    headline: "Generative AI can be used in proposal preparation, but accountability stays with the proposer.",
    whyItMatters:
      "NSF's notice encourages proposers to indicate how generative AI was used while holding applicants responsible for proposal accuracy, authenticity, and integrity.",
    practiceShift: [
      "Treat AI as an assistant, not an author-of-record.",
      "Document where AI was used (idea expansion, editing, structure checks, etc.).",
      "Run a manual fact and citation audit before submission."
    ],
    activity:
      "Open one of your current sections and mark lines that are AI-assisted versus PI-authored. Then identify which claims still need evidence checks.",
    source: "https://www.nsf.gov/news/notice-to-the-research-community-on-ai"
  },
  {
    id: "nsf-confidentiality",
    tag: "NSF Risk Signal",
    headline: "Confidentiality remains a major boundary for AI use in review and proposal contexts.",
    whyItMatters:
      "NSF's notice explicitly flags that current-generation AI tools may not meet confidentiality standards and may release information to third parties.",
    practiceShift: [
      "Do not paste unpublished partner-sensitive material into consumer AI tools.",
      "Use institution-approved tools for sensitive drafts.",
      "Build redaction steps into your team workflow."
    ],
    activity:
      "Create a two-column table: 'Safe to share with AI' and 'Never upload'. Include data, student info, proprietary methods, and collaborators' unpublished content.",
    source: "https://www.nsf.gov/news/notice-to-the-research-community-on-ai"
  },
  {
    id: "merit-review",
    tag: "NSB/NSF Direction",
    headline: "Merit review is being reframed toward societal benefit, national priorities, and broader participation.",
    whyItMatters:
      "NSB's December 17, 2025 update calls for stronger societal outcomes, strategic portfolio alignment, and broader reviewer participation across sectors.",
    practiceShift: [
      "State benefits to people and systems, not only knowledge gain.",
      "Show how your project aligns with urgent societal or national challenges.",
      "Design collaboration plans beyond your immediate discipline."
    ],
    activity:
      "Rewrite your project's first paragraph so a non-specialist dean can explain why taxpayers should fund it in 30 seconds.",
    source: "https://www.nsf.gov/nsb/updates/merit-review-new-era-nsf"
  },
  {
    id: "pappg",
    tag: "Compliance Signal",
    headline: "PAPPG remains central, with active supplements and process updates you must track.",
    whyItMatters:
      "NSF lists PAPPG 24-1 as current and highlights Supplements NSF 26-200 and NSF 26-202, plus ongoing process streamlining priorities in the FY 2026-2030 plan.",
    practiceShift: [
      "Treat final compliance review as a scheduled milestone, not a last-day check.",
      "Crosswalk solicitation rules + CAREER rules + current PAPPG requirements.",
      "Expect procedural updates and plan a final policy refresh close to deadline."
    ],
    activity:
      "Build a one-page compliance checklist with owner + due date for every required CAREER artifact.",
    source: "https://www.nsf.gov/policies/pappg"
  },
  {
    id: "cross-agency",
    tag: "Cross-Agency Trend",
    headline: "Agencies are diverging on AI specifics but converging on integrity and confidentiality.",
    whyItMatters:
      "NIH prohibits generative AI for peer review critiques; NEH allows applicant AI use but requires acknowledgement for inserted AI-generated text.",
    practiceShift: [
      "Do not assume one agency's AI norm applies to another.",
      "Create an agency-specific AI use protocol for each submission.",
      "Train proposal teams on confidentiality boundaries before drafting starts."
    ],
    activity:
      "Draft a short 'AI use statement' template with three versions: NSF-style, NIH-style, and NEH-style workflow language.",
    source: "https://grants.nih.gov/grants/guide/notice-files/NOT-OD-23-149.html"
  }
];

const grantStages = [
  {
    id: "positioning",
    title: "1) Positioning and Program Fit",
    prompt:
      "I am preparing an NSF CAREER proposal in [FIELD]. Ask me 12 high-value scoping questions that reveal whether my idea fits CAREER and where the biggest review risks are.",
    riskChecks: [
      "Weak or generic articulation of the CAREER integration vision.",
      "Topic fit not tested with program officer language.",
      "Education plan disconnected from research core."
    ],
    activity:
      "Draft a 150-word 'Why CAREER, why now, why me' statement. Peer partners should underline every phrase that sounds generic."
  },
  {
    id: "design",
    title: "2) Project Architecture",
    prompt:
      "Act as a skeptical NSF panelist. Given my aims below, identify hidden feasibility risks, missing milestones, and what evidence would make each aim believable.",
    riskChecks: [
      "Overpacked aims without realistic sequencing.",
      "Methods not connected to testable outcomes.",
      "No contingency plan for technical failure."
    ],
    activity:
      "Create a milestone table (Year 1-5) with deliverables, decision points, and fallback paths."
  },
  {
    id: "narrative",
    title: "3) Narrative Quality and Reviewer Experience",
    prompt:
      "Review this draft as a tired panelist reading at 11 PM. Flag sections that are vague, repetitive, jargon-heavy, or unsupported, and propose concise replacements.",
    riskChecks: [
      "Claims without evidence or scale indicators.",
      "Narrative rhythm too uniform, causing low readability.",
      "Copilot-style over-polished tone with minimal disciplinary specificity."
    ],
    activity:
      "Run a reverse-outline pass: extract one sentence per paragraph; check if the argument still forms a coherent chain."
  },
  {
    id: "broader-impacts",
    title: "4) Broader Impacts in the AI Era",
    prompt:
      "Using NSF broader impacts criteria, critique this outreach plan for measurability, equity, feasibility, and societal relevance in an AI-transformed landscape.",
    riskChecks: [
      "Outreach listed as activities rather than outcomes.",
      "No evaluation mechanism or baseline.",
      "No connection to current societal AI challenges."
    ],
    activity:
      "For each outreach activity, add one measurable outcome metric and one evidence source you can realistically collect."
  },
  {
    id: "final",
    title: "5) Final Red-Team and Compliance",
    prompt:
      "Act as a compliance and strategy reviewer. Build a final 20-item pre-submission checklist for NSF CAREER that includes policy, coherence, and reviewer-persuasion checks.",
    riskChecks: [
      "Missing required documents or weak required statements.",
      "Inconsistent terminology across sections.",
      "PI narrative voice lost due to patchwork editing."
    ],
    activity:
      "Run a final 'single-voice edit' to align tone, terminology, and confidence level across all major sections."
  }
];

const promptLibrary = [
  {
    id: "im",
    category: "Intellectual Merit",
    title: "Argument Stress Test",
    prompt:
      "You are an NSF panelist. Evaluate this project description for intellectual merit only. Return: (1) strongest claim, (2) weakest claim, (3) missing evidence, (4) one revision that would most improve competitiveness."
  },
  {
    id: "bi",
    category: "Broader Impacts",
    title: "Outcome Mapping",
    prompt:
      "Convert this broader impacts draft into a table with columns: activity, target population, intended outcome, evidence metric, timeline, responsible partner, and risk mitigation."
  },
  {
    id: "concerns",
    category: "Reviewer Concerns",
    title: "Panel Skeptic Generator",
    prompt:
      "Generate 15 realistic reviewer concerns for this CAREER draft, grouped by feasibility, novelty, integration of research and education, broader impacts, and evaluation."
  },
  {
    id: "clarity",
    category: "Narrative Clarity",
    title: "Plain-Language Reframer",
    prompt:
      "Rewrite this section for a cross-disciplinary NSF panel. Preserve technical accuracy, reduce jargon, and keep each paragraph under 120 words."
  },
  {
    id: "ai-style",
    category: "AI Quality Control",
    title: "AI-Tell Audit",
    prompt:
      "Identify likely AI-generated writing tells in this draft: vague abstractions, repetitive transitions, unsupported superlatives, and generic claims. Provide line-level edits that restore specificity and PI voice."
  },
  {
    id: "po-prep",
    category: "Program Officer Prep",
    title: "Program Officer Call Prep",
    prompt:
      "Create a 1-page briefing for my program officer conversation: project essence, likely fit questions, likely misfit risks, and 8 concise questions to ask during the meeting."
  },
  {
    id: "custom-prompts",
    category: "Custom CAREER Prompt Triage",
    title: "Prompt Quality Critique",
    prompt:
      "Evaluate each prompt in my list using this rubric: context quality, task clarity, output constraints, evaluation criteria, and risk/safety boundaries. For each prompt, suggest one improved version and explain why it is stronger."
  }
];

const broaderImpactChallenges = [
  {
    challenge: "AI literacy gaps across K-12, undergraduate, and public audiences",
    opportunities: [
      "Discipline-specific AI literacy micro-modules linked to your research domain",
      "Hands-on workshops that teach uncertainty, bias, and verification",
      "Train-the-trainer models with local educators"
    ]
  },
  {
    challenge: "Mistrust, misinformation, and weak evidence evaluation skills",
    opportunities: [
      "Public-facing explanation assets that compare claim vs. evidence",
      "Community research briefings with transparent uncertainty language",
      "Student ambassador models for science communication"
    ]
  },
  {
    challenge: "Workforce transitions and uneven access to AI-enabled tools",
    opportunities: [
      "Career-aligned modules for community college and transfer students",
      "Partnerships with industry/nonprofits for practical exposure",
      "Mentorship pathways for historically underrepresented learners"
    ]
  },
  {
    challenge: "Ethics, privacy, and responsible use in research and education",
    opportunities: [
      "Responsible AI checklists embedded in course/project workflows",
      "Scenario-based ethics labs connected to your research methods",
      "Data stewardship training integrated with broader impacts activities"
    ]
  }
];

const sourceLinks = [
  {
    label: "NSF CAREER Solicitation (NSF 22-586)",
    url: "https://www.nsf.gov/funding/opportunities/career-faculty-early-career-development-program/nsf22-586/solicitation"
  },
  {
    label: "NSF CAREER FAQ (Submission Years 2022-2026)",
    url: "https://www.nsf.gov/funding/information/faq-faculty-early-career-development-career-program"
  },
  {
    label: "NSF PAPPG (current page with supplements)",
    url: "https://www.nsf.gov/policies/pappg"
  },
  {
    label: "NSF Notice on Generative AI in Merit Review",
    url: "https://www.nsf.gov/news/notice-to-the-research-community-on-ai"
  },
  {
    label: "NSF Merit Review Overview",
    url: "https://www.nsf.gov/funding/merit-review"
  },
  {
    label: "NSF Broader Impacts Guidance",
    url: "https://www.nsf.gov/funding/learn/broader-impacts"
  },
  {
    label: "NSB update: Merit review for a new era at NSF (Dec 17, 2025)",
    url: "https://www.nsf.gov/nsb/updates/merit-review-new-era-nsf"
  },
  {
    label: "NSF FY 2026-2030 Strategic Plan",
    url: "https://www.nsf.gov/about/performance/strategic-plan/nsf-fy-2026-2030"
  },
  {
    label: "NIH: Generative AI Prohibited in NIH Peer Review (NOT-OD-23-149)",
    url: "https://grants.nih.gov/grants/guide/notice-files/NOT-OD-23-149.html"
  },
  {
    label: "NEH: Policy on AI Use for Grant Proposals (Oct 23, 2024)",
    url: "https://www.neh.gov/sites/default/files/2024-10/NEH.AI_.Policy-10.23.24.pdf"
  },
  {
    label: "Turnitin AI Writing Report guidance",
    url: "https://guides.turnitin.com/hc/en-us/articles/22774058814093-Using-the-AI-Writing-Report"
  },
  {
    label: "OpenAI classifier retirement note (low accuracy)",
    url: "https://openai.com/index/new-ai-classifier-for-indicating-ai-written-text/"
  },
  {
    label: "NIST 2024 GenAI Pilot Study (text generation/detection)",
    url: "https://www.nist.gov/publications/2024-nist-genai-pilot-study-text-text-evaluation-overview-and-results"
  }
];

const defaultPromptForm = {
  role: "NSF CAREER mock reviewer",
  context: "Early-career faculty proposal in [YOUR DISCIPLINE]",
  task: "Identify the top five reviewer concerns and one high-leverage revision for each.",
  constraints: "Return in a table. Keep each revision suggestion under 80 words.",
  success: "Cite the exact sentence/claim that triggers each concern.",
  fallback: "If evidence is insufficient, say 'insufficient evidence' and list what is missing."
};

function copyText(value) {
  if (!value) return;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(value).catch(() => {
      window.prompt("Copy prompt:", value);
    });
    return;
  }
  window.prompt("Copy prompt:", value);
}

function analyzeDraft(text) {
  const clean = text.trim();
  if (!clean) return null;

  const words = clean.split(/\s+/).filter(Boolean);
  const sentences = clean.split(/(?<=[.!?])\s+/).filter(Boolean);
  const lower = clean.toLowerCase();

  const buzzwords = ["transformative", "robust", "novel", "cutting-edge", "impactful", "state-of-the-art"];
  const hedges = ["may", "might", "could", "potentially", "possibly", "suggests", "appears"];

  const buzzwordHits = buzzwords.reduce((acc, word) => acc + (lower.match(new RegExp(`\\b${word}\\b`, "g")) || []).length, 0);
  const hedgeHits = hedges.reduce((acc, word) => acc + (lower.match(new RegExp(`\\b${word}\\b`, "g")) || []).length, 0);
  const numberHits = (clean.match(/\d+/g) || []).length;

  const avgSentenceLength = sentences.length ? Math.round(words.length / sentences.length) : words.length;
  const firstWords = sentences
    .map((s) => s.trim().split(/\s+/)[0]?.toLowerCase())
    .filter(Boolean);
  const repetitiveStarts = Math.max(
    0,
    firstWords.length - new Set(firstWords).size
  );

  const concerns = [];
  const opportunities = [];

  if (words.length < 220) {
    concerns.push("Draft section is short; reviewers may not see enough evidentiary depth.");
  } else {
    opportunities.push("Draft length suggests enough room for argument development.");
  }

  if (buzzwordHits >= 5) {
    concerns.push("High buzzword density may read as generic or AI-polished without substance.");
  } else {
    opportunities.push("Buzzword use is moderate; easier to preserve authentic PI voice.");
  }

  if (hedgeHits >= 8) {
    concerns.push("Frequent hedging weakens confidence and feasibility framing.");
  } else {
    opportunities.push("Confidence language is relatively controlled.");
  }

  if (numberHits < 5) {
    concerns.push("Low number of concrete metrics/timelines can make plans feel underspecified.");
  } else {
    opportunities.push("Concrete quantities/timelines are present and can anchor reviewer trust.");
  }

  if (avgSentenceLength > 30) {
    concerns.push("Average sentence length is high; panel readability risk under time pressure.");
  } else {
    opportunities.push("Sentence length is likely manageable for fast panel reading.");
  }

  if (repetitiveStarts > 3) {
    concerns.push("Repeated sentence openings suggest formulaic style; revise for rhetorical variation.");
  }

  return {
    wordCount: words.length,
    sentenceCount: sentences.length,
    avgSentenceLength,
    buzzwordHits,
    hedgeHits,
    numberHits,
    repetitiveStarts,
    concerns,
    opportunities
  };
}

function scorePrompt(prompt) {
  const trimmed = prompt.trim();
  if (!trimmed) return null;

  const lower = trimmed.toLowerCase();

  const hasContext = /(career|nsf|discipline|proposal|panel|reviewer)/.test(lower);
  const hasTaskVerb = /(identify|evaluate|rewrite|critique|generate|compare|rank|summarize|map)/.test(lower);
  const hasOutputConstraints = /(table|bullets|json|word|limit|under|format|columns)/.test(lower);
  const hasSuccessCriteria = /(criteria|evidence|why|because|justify|score|rubric)/.test(lower);
  const hasFallback = /(if|when).*(insufficient|missing|unknown|not found|cannot)/.test(lower);

  const points = [hasContext, hasTaskVerb, hasOutputConstraints, hasSuccessCriteria, hasFallback].filter(Boolean).length;

  return {
    points,
    max: 5,
    details: [
      { label: "Context specificity", ok: hasContext },
      { label: "Clear action task", ok: hasTaskVerb },
      { label: "Output constraints", ok: hasOutputConstraints },
      { label: "Evaluation criteria", ok: hasSuccessCriteria },
      { label: "Fallback / uncertainty handling", ok: hasFallback }
    ]
  };
}

export default function App() {
  const [trendId, setTrendId] = useState(fundingTrends[0].id);
  const [stageId, setStageId] = useState(grantStages[0].id);
  const [draftText, setDraftText] = useState("");
  const [copiedId, setCopiedId] = useState("");
  const [reflection, setReflection] = useState(() => {
    return localStorage.getItem("careerWorkshopReflection") || "";
  });
  const [promptAuditInput, setPromptAuditInput] = useState("");
  const [promptBuilder, setPromptBuilder] = useState(defaultPromptForm);

  useEffect(() => {
    const timer = setTimeout(() => {
      localStorage.setItem("careerWorkshopReflection", reflection);
    }, 200);
    return () => clearTimeout(timer);
  }, [reflection]);

  const selectedTrend = useMemo(
    () => fundingTrends.find((item) => item.id === trendId) ?? fundingTrends[0],
    [trendId]
  );

  const selectedStage = useMemo(
    () => grantStages.find((item) => item.id === stageId) ?? grantStages[0],
    [stageId]
  );

  const analysis = useMemo(() => analyzeDraft(draftText), [draftText]);
  const promptScore = useMemo(() => scorePrompt(promptAuditInput), [promptAuditInput]);

  const builtPrompt = useMemo(() => {
    return [
      `Role: ${promptBuilder.role}`,
      `Context: ${promptBuilder.context}`,
      `Task: ${promptBuilder.task}`,
      `Output constraints: ${promptBuilder.constraints}`,
      `Success criteria: ${promptBuilder.success}`,
      `Fallback behavior: ${promptBuilder.fallback}`
    ].join("\n");
  }, [promptBuilder]);

  const analysisPrompt = useMemo(() => {
    return [
      "You are an NSF CAREER pre-review analyst.",
      "Read the draft section I paste below.",
      "Return:",
      "1) 5 likely reviewer concerns,",
      "2) 5 revision opportunities,",
      "3) line-level rewrite suggestions for the top 3 concerns,",
      "4) confidence level (high/medium/low) for each concern and why.",
      "Do not invent evidence; if a claim is unsupported, label it clearly.",
      "",
      "[PASTE DRAFT SECTION HERE]"
    ].join("\n");
  }, []);

  const handleCopy = (id, text) => {
    copyText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(""), 1500);
  };

  const jumpTo = (id) => {
    const target = document.getElementById(id);
    if (target) {
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <div className="workshop-shell">
      <header className="hero">
        <p className="eyebrow">University of Mississippi Workshop Builder</p>
        <h1>NSF CAREER in the AI Era: Interactive Deep-Dive Studio</h1>
        <p className="lede">
          Use this site to run intensive activities on grant strategy, AI-assisted drafting,
          narrative risk detection, and broader impacts design.
        </p>
        <div className="hero-meta">
          <span>Last policy refresh: {LAST_UPDATED}</span>
          <span>Format: Static site (GitHub hostable)</span>
        </div>
        <nav className="quick-nav" aria-label="Workshop sections">
          <button onClick={() => jumpTo("trends")}>Funding Trends</button>
          <button onClick={() => jumpTo("process")}>Grant Process Lab</button>
          <button onClick={() => jumpTo("ai-review")}>AI Draft Review Lab</button>
          <button onClick={() => jumpTo("copilot")}>Copilot Prompt Studio</button>
          <button onClick={() => jumpTo("impacts")}>Broader Impacts Canvas</button>
          <button onClick={() => jumpTo("reflect")}>Reflection Journal</button>
          <button onClick={() => jumpTo("sources")}>Sources</button>
        </nav>
      </header>

      <main className="content-grid">
        <section id="trends" className="panel">
          <h2>Current Funding-Agency Trends (with NSF emphasis)</h2>
          <p className="panel-intro">
            Activity: Choose one trend, map one risk and one immediate action for your current draft.
          </p>
          <div className="chip-row">
            {fundingTrends.map((trend) => (
              <button
                key={trend.id}
                className={trend.id === trendId ? "chip chip-active" : "chip"}
                onClick={() => setTrendId(trend.id)}
              >
                {trend.tag}
              </button>
            ))}
          </div>

          <article className="trend-card">
            <h3>{selectedTrend.headline}</h3>
            <p>{selectedTrend.whyItMatters}</p>
            <h4>Common Practice Shift</h4>
            <ul>
              {selectedTrend.practiceShift.map((line) => (
                <li key={line}>{line}</li>
              ))}
            </ul>
            <h4>Deep-Dive Activity</h4>
            <p>{selectedTrend.activity}</p>
            <p className="source-link">
              Source: <a href={selectedTrend.source}>{selectedTrend.source}</a>
            </p>
          </article>
        </section>

        <section id="process" className="panel">
          <h2>Grant-Writing Process Studio</h2>
          <p className="panel-intro">
            Activity flow: move through all five stages and complete each stage exercise before drafting final edits.
          </p>

          <div className="stage-layout">
            <div className="stage-list" role="tablist" aria-label="Grant stages">
              {grantStages.map((stage) => (
                <button
                  key={stage.id}
                  role="tab"
                  aria-selected={stage.id === stageId}
                  className={stage.id === stageId ? "stage-btn stage-btn-active" : "stage-btn"}
                  onClick={() => setStageId(stage.id)}
                >
                  {stage.title}
                </button>
              ))}
            </div>
            <article className="stage-card" role="tabpanel">
              <h3>{selectedStage.title}</h3>
              <h4>Failure Points to Check</h4>
              <ul>
                {selectedStage.riskChecks.map((risk) => (
                  <li key={risk}>{risk}</li>
                ))}
              </ul>
              <h4>Deep-Dive Activity</h4>
              <p>{selectedStage.activity}</p>
              <h4>Microsoft Copilot Prompt Exemplar</h4>
              <pre>{selectedStage.prompt}</pre>
              <button
                className="copy-btn"
                onClick={() => handleCopy(`stage-${selectedStage.id}`, selectedStage.prompt)}
              >
                {copiedId === `stage-${selectedStage.id}` ? "Copied" : "Copy Prompt"}
              </button>
            </article>
          </div>
        </section>

        <section id="ai-review" className="panel">
          <h2>AI Draft Review and "AI Tell" Detection Lab</h2>
          <p className="panel-intro">
            Paste a narrative section and use this analyzer to identify common over-automation patterns.
          </p>
          <label htmlFor="draftText" className="label">
            Draft narrative (Project Description, BI section, or summary)
          </label>
          <textarea
            id="draftText"
            value={draftText}
            onChange={(event) => setDraftText(event.target.value)}
            placeholder="Paste your draft text here..."
            rows={10}
          />

          {analysis ? (
            <div className="analysis-grid">
              <div className="metric-card">
                <p>Words</p>
                <strong>{analysis.wordCount}</strong>
              </div>
              <div className="metric-card">
                <p>Sentences</p>
                <strong>{analysis.sentenceCount}</strong>
              </div>
              <div className="metric-card">
                <p>Avg sentence length</p>
                <strong>{analysis.avgSentenceLength}</strong>
              </div>
              <div className="metric-card">
                <p>Buzzword hits</p>
                <strong>{analysis.buzzwordHits}</strong>
              </div>
              <div className="metric-card">
                <p>Hedging hits</p>
                <strong>{analysis.hedgeHits}</strong>
              </div>
              <div className="metric-card">
                <p>Numeric anchors</p>
                <strong>{analysis.numberHits}</strong>
              </div>
            </div>
          ) : null}

          {analysis ? (
            <div className="two-col">
              <div>
                <h4>Potential Concerns</h4>
                <ul>
                  {analysis.concerns.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
              <div>
                <h4>Potential Opportunities</h4>
                <ul>
                  {analysis.opportunities.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </div>
          ) : null}

          <h4>Copilot Red-Team Prompt</h4>
          <pre>{analysisPrompt}</pre>
          <button className="copy-btn" onClick={() => handleCopy("analysis", analysisPrompt)}>
            {copiedId === "analysis" ? "Copied" : "Copy Prompt"}
          </button>

          <p className="callout">
            Facilitator note: AI detectors are not definitive proof. Use them as triage, then apply human judgment,
            evidence checks, and disciplinary review.
          </p>
        </section>

        <section id="copilot" className="panel">
          <h2>Microsoft Copilot Prompt Studio</h2>
          <p className="panel-intro">
            Includes exemplars plus a builder you can reuse when participants share custom CAREER prompts this week.
          </p>

          <div className="prompt-grid">
            {promptLibrary.map((item) => (
              <article key={item.id} className="prompt-card">
                <p className="prompt-category">{item.category}</p>
                <h3>{item.title}</h3>
                <pre>{item.prompt}</pre>
                <button className="copy-btn" onClick={() => handleCopy(item.id, item.prompt)}>
                  {copiedId === item.id ? "Copied" : "Copy Prompt"}
                </button>
              </article>
            ))}
          </div>

          <div className="builder">
            <h3>Prompt Builder (Role + Context + Constraints)</h3>
            <div className="builder-grid">
              {Object.keys(promptBuilder).map((key) => (
                <label key={key} className="label">
                  {key}
                  <textarea
                    rows={2}
                    value={promptBuilder[key]}
                    onChange={(event) =>
                      setPromptBuilder((prev) => ({
                        ...prev,
                        [key]: event.target.value
                      }))
                    }
                  />
                </label>
              ))}
            </div>
            <h4>Built Prompt</h4>
            <pre>{builtPrompt}</pre>
            <button className="copy-btn" onClick={() => handleCopy("built", builtPrompt)}>
              {copiedId === "built" ? "Copied" : "Copy Prompt"}
            </button>
          </div>

          <div className="triage">
            <h3>Prompt Quality Triage (for your upcoming CAREER prompt list)</h3>
            <label htmlFor="audit" className="label">
              Paste one draft prompt
            </label>
            <textarea
              id="audit"
              rows={5}
              value={promptAuditInput}
              onChange={(event) => setPromptAuditInput(event.target.value)}
              placeholder="Example: Review my broader impacts section and suggest improvements..."
            />

            {promptScore ? (
              <div className="score-card">
                <p>
                  Prompt score: <strong>{promptScore.points} / {promptScore.max}</strong>
                </p>
                <ul>
                  {promptScore.details.map((detail) => (
                    <li key={detail.label}>
                      {detail.ok ? "PASS" : "ADD"}: {detail.label}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        </section>

        <section id="impacts" className="panel">
          <h2>Broader Impacts Canvas: Challenges and Opportunities in the AI Era</h2>
          <p className="panel-intro">
            Deep-dive activity: select one challenge, design one evidence-backed intervention, and define one metric you can collect in year one.
          </p>

          <div className="impact-grid">
            {broaderImpactChallenges.map((item) => (
              <article key={item.challenge} className="impact-card">
                <h3>{item.challenge}</h3>
                <h4>Potential Response Designs</h4>
                <ul>
                  {item.opportunities.map((opportunity) => (
                    <li key={opportunity}>{opportunity}</li>
                  ))}
                </ul>
                <h4>Copilot Prompt Exemplar</h4>
                <pre>
{`I am drafting a CAREER broader impacts plan.
Challenge: ${item.challenge}
Generate a 2-year implementation plan with:
- target audience
- activities
- measurable outcomes
- evaluation data to collect
- equity/risk considerations
Return as a month-by-month milestone table.`}
                </pre>
              </article>
            ))}
          </div>
        </section>

        <section id="reflect" className="panel">
          <h2>Reflection Journal</h2>
          <p className="panel-intro">
            Reflection checkpoint prompts:
            1) What is the highest-risk weakness in my current CAREER story?
            2) Which AI-assisted practice improves quality without compromising integrity?
            3) What one broader impacts change would most improve reviewer confidence?
          </p>
          <textarea
            rows={10}
            value={reflection}
            onChange={(event) => setReflection(event.target.value)}
            placeholder="Type reflection notes here. Notes persist in this browser."
          />
        </section>

        <section id="sources" className="panel">
          <h2>Source Deck</h2>
          <p className="panel-intro">
            These links ground the workshop's policy and practice guidance. Re-check before live delivery in case of agency updates.
          </p>
          <ul className="source-list">
            {sourceLinks.map((source) => (
              <li key={source.url}>
                <a href={source.url}>{source.label}</a>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}
