import { MessageSquareMore, ScrollText, Swords } from "lucide-react";
import Panel from "./Panel";

export default function ActionPanel({ npcs, onTalk, onDuel, talkBusy }) {
  return (
    <Panel title="Social Field" subtitle="Talk, provoke, or test rhetoric" className="h-full">
      <div className="space-y-3">
        {npcs.map((npc) => (
          <div
            key={npc.id}
            className="rounded-xl border border-black/10 bg-white/80 p-3 dark:border-white/15 dark:bg-zinc-800/70"
          >
            <div className="mb-2 flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold text-zinc-900 dark:text-zinc-100">{npc.name}</p>
                <p className="text-xs text-zinc-600 dark:text-zinc-400">{npc.role}</p>
              </div>
              <span className="rounded-full bg-zinc-100 px-2 py-1 text-[10px] uppercase tracking-wider text-zinc-600 dark:bg-zinc-700 dark:text-zinc-200">
                {npc.bookSource}
              </span>
            </div>
            <p className="mb-3 text-xs italic text-zinc-700 dark:text-zinc-300">"{npc.openingLine}"</p>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => onTalk(npc.id)}
                disabled={talkBusy}
                className="inline-flex items-center gap-1 rounded-full bg-moss px-3 py-1.5 text-xs font-semibold text-zinc-50 transition hover:brightness-110 disabled:opacity-55"
              >
                <MessageSquareMore size={13} /> Converse
              </button>
              <button
                type="button"
                onClick={() => onDuel(npc.id)}
                className="inline-flex items-center gap-1 rounded-full bg-dusk px-3 py-1.5 text-xs font-semibold text-zinc-50 transition hover:brightness-110"
              >
                <Swords size={13} /> Duel of Wits
              </button>
              <button
                type="button"
                onClick={() => onTalk(npc.id, "Offer to compare notes and citations.")}
                disabled={talkBusy}
                className="inline-flex items-center gap-1 rounded-full border border-black/15 bg-white px-3 py-1.5 text-xs font-semibold text-zinc-800 transition hover:bg-zinc-50 disabled:opacity-60 dark:border-white/20 dark:bg-zinc-700 dark:text-zinc-100 dark:hover:bg-zinc-600"
              >
                <ScrollText size={13} /> Compare Notes
              </button>
            </div>
          </div>
        ))}
        {!npcs.length ? <p className="text-sm text-zinc-500">No active NPCs in this zone.</p> : null}
      </div>
    </Panel>
  );
}
