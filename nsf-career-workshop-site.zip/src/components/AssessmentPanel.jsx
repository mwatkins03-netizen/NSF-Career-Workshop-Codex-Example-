import { BarChart3 } from "lucide-react";
import Panel from "./Panel";

export default function AssessmentPanel({ assessment, onRun, busy, gameOver }) {
  return (
    <Panel
      title="Assessment Layer"
      subtitle="Scores gameplay via logs, journal, dialogue, and outcomes"
      right={
        <button
          type="button"
          onClick={onRun}
          disabled={busy}
          className="inline-flex items-center gap-1 rounded-full bg-zinc-900 px-3 py-1.5 text-xs font-semibold text-zinc-50 disabled:opacity-60 dark:bg-zinc-100 dark:text-zinc-900"
        >
          <BarChart3 size={13} /> Run Assessment
        </button>
      }
    >
      {gameOver ? (
        <p className="mb-2 rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-xs text-rose-800 dark:border-rose-900 dark:bg-rose-950/40 dark:text-rose-100">
          <span className="font-semibold">Game Over:</span> {gameOver.reason} — {gameOver.outcome}
        </p>
      ) : null}

      {assessment ? (
        <div className="space-y-2 text-xs">
          <p className="text-sm font-semibold">Score: {assessment.score}/100</p>
          <div className="grid gap-2 sm:grid-cols-2">
            <p>Historical grounding: {assessment.breakdown.historicalGrounding}</p>
            <p>Social navigation: {assessment.breakdown.socialNavigation}</p>
            <p>Documentation: {assessment.breakdown.documentation}</p>
            <p>Strategy: {assessment.breakdown.strategy}</p>
            <p>Consistency: {assessment.breakdown.consistency}</p>
          </div>
          <p className="rounded-lg bg-zinc-100 p-2 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">{assessment.summary}</p>
          <p className="font-semibold">Strengths</p>
          <ul className="list-disc pl-4">
            {assessment.strengths.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
          <p className="font-semibold">Missed Opportunities</p>
          <ul className="list-disc pl-4">
            {assessment.missedOpportunities.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="text-xs text-zinc-500">No assessment yet. Run manually or wait for endgame.</p>
      )}
    </Panel>
  );
}
