import { useMemo, useState } from "react";
import Panel from "./Panel";

export default function DialoguePanel({ transcript, onSend, isBusy }) {
  const [input, setInput] = useState("");

  const latest = useMemo(() => transcript.slice(-8).reverse(), [transcript]);

  return (
    <Panel title="Dialogue Transcript" subtitle="All NPC exchanges are recorded for assessment">
      <form
        onSubmit={(event) => {
          event.preventDefault();
          if (!input.trim()) return;
          onSend(input.trim());
          setInput("");
        }}
        className="mb-3 flex gap-2"
      >
        <input
          value={input}
          onChange={(event) => setInput(event.target.value)}
          placeholder="Type a line and the nearest NPC will respond"
          className="w-full rounded-lg border border-black/15 bg-white/90 px-3 py-2 text-sm outline-none ring-emerald-300 transition focus:ring-2 dark:border-white/20 dark:bg-zinc-800"
        />
        <button
          type="submit"
          disabled={isBusy}
          className="rounded-lg bg-zinc-900 px-3 py-2 text-xs font-semibold text-zinc-50 transition hover:brightness-110 disabled:opacity-60 dark:bg-zinc-100 dark:text-zinc-900"
        >
          Send
        </button>
      </form>

      <div className="max-h-64 space-y-2 overflow-y-auto pr-1">
        {latest.map((entry) => (
          <div
            key={entry.id}
            className={`rounded-lg border px-3 py-2 text-xs ${
              entry.speaker === "You"
                ? "border-emerald-300 bg-emerald-50 text-emerald-900 dark:border-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-100"
                : "border-black/10 bg-white text-zinc-800 dark:border-white/15 dark:bg-zinc-800 dark:text-zinc-100"
            }`}
          >
            <p className="mb-1 font-semibold">{entry.speaker}</p>
            <p>{entry.text}</p>
          </div>
        ))}
        {!latest.length ? <p className="text-xs text-zinc-500">No dialogue yet.</p> : null}
      </div>
    </Panel>
  );
}
