import { DUEL_MOVES } from "../constants/gameplay";
import { NPC_BY_ID } from "../constants/npcs";
import Panel from "./Panel";

export default function DuelCard({ duel, onMove }) {
  if (!duel) return null;

  const npc = NPC_BY_ID[duel.npcId];

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-black/35 p-3 md:items-center">
      <Panel
        title={`Duel of Wits vs ${npc?.name ?? "Opponent"}`}
        subtitle="Belle Epoque rhetoric combat: allusions, jibes, innuendo, and rumor"
        className="w-full max-w-3xl"
      >
        <div className="mb-3 grid gap-3 md:grid-cols-2">
          <div>
            <p className="mb-1 text-xs uppercase tracking-wide text-zinc-500">Your Composure</p>
            <div className="h-3 rounded-full bg-zinc-200 dark:bg-zinc-700">
              <div className="h-3 rounded-full bg-emerald-500" style={{ width: `${Math.max(0, duel.playerComposure)}%` }} />
            </div>
          </div>
          <div>
            <p className="mb-1 text-xs uppercase tracking-wide text-zinc-500">{npc?.name} Composure</p>
            <div className="h-3 rounded-full bg-zinc-200 dark:bg-zinc-700">
              <div className="h-3 rounded-full bg-rose-500" style={{ width: `${Math.max(0, duel.npcComposure)}%` }} />
            </div>
          </div>
        </div>

        <div className="mb-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {DUEL_MOVES.map((move) => (
            <button
              key={move.id}
              type="button"
              onClick={() => onMove(move.id)}
              className="rounded-lg border border-black/15 bg-white p-2 text-left text-xs transition hover:border-zinc-700 dark:border-white/20 dark:bg-zinc-800 dark:hover:border-zinc-300"
            >
              <p className="font-semibold">{move.name}</p>
              <p className="text-zinc-600 dark:text-zinc-400">{move.flavor}</p>
            </button>
          ))}
        </div>

        <div className="max-h-32 space-y-1 overflow-y-auto rounded-lg bg-zinc-100 p-2 text-xs dark:bg-zinc-900">
          {duel.history.slice(0, 8).map((round) => (
            <p key={round.round}>
              R{round.round}: {round.playerMove.name} ({round.playerDamage}) • {round.npcMove.name} ({round.npcDamage})
            </p>
          ))}
          {!duel.history.length ? <p>Round opens. Choose your move.</p> : null}
        </div>
      </Panel>
    </div>
  );
}
