import Panel from "./Panel";

export default function EventCard({ event, onChoose }) {
  if (!event) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-3 backdrop-blur-sm">
      <Panel
        title={event.title}
        subtitle={`Triggered by ${event.source === "llm" ? "dynamic LLM event" : "scripted county condition"}`}
        className="max-h-[90vh] w-full max-w-2xl overflow-y-auto"
      >
        <p className="mb-4 text-sm text-zinc-700 dark:text-zinc-200">{event.summary}</p>
        <div className="space-y-2">
          {event.choices.map((choice, index) => (
            <button
              key={choice.text}
              type="button"
              onClick={() => onChoose(index)}
              className="block w-full rounded-xl border border-black/12 bg-white px-3 py-2 text-left text-sm transition hover:border-zinc-700 dark:border-white/15 dark:bg-zinc-800 dark:hover:border-zinc-200"
            >
              {index + 1}. {choice.text}
            </button>
          ))}
        </div>
      </Panel>
    </div>
  );
}
