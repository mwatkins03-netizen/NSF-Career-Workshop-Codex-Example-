import { CheckCircle2, ExternalLink, HelpCircle, ShieldAlert, XCircle } from "lucide-react";
import Panel from "./Panel";
import { useState } from "react";

function verdictIcon(verdict) {
  if (verdict === "accurate") return <CheckCircle2 size={14} className="text-emerald-500" />;
  if (verdict === "inaccurate") return <XCircle size={14} className="text-rose-500" />;
  if (verdict === "mixed") return <ShieldAlert size={14} className="text-amber-500" />;
  return <HelpCircle size={14} className="text-zinc-500" />;
}

export default function FactCheckPanel({ result, onCheck, busy }) {
  const [draftClaim, setDraftClaim] = useState("");

  return (
    <Panel
      title="Fact Check Agent"
      subtitle="Standalone veracity layer + Wikipedia context"
      right={
        <button
          type="button"
          onClick={() =>
            onCheck(
              draftClaim.trim() || result?.claim || "Was this event historically plausible for Lafayette County?"
            )
          }
          disabled={busy}
          className="rounded-full bg-zinc-900 px-3 py-1.5 text-[11px] font-semibold text-zinc-50 dark:bg-zinc-100 dark:text-zinc-900"
        >
          Re-check
        </button>
      }
    >
      <label className="mb-2 block text-xs">
        Claim to verify
        <input
          value={draftClaim}
          onChange={(event) => setDraftClaim(event.target.value)}
          placeholder="Example: The museum currently shows Caribbean collection works."
          className="mt-1 w-full rounded-lg border border-black/15 bg-white/90 px-2 py-2 text-xs outline-none ring-blue-300 focus:ring-2 dark:border-white/20 dark:bg-zinc-800"
        />
      </label>

      {result ? (
        <div className="space-y-2 text-xs">
          <p className="rounded-lg border border-black/10 bg-zinc-50 p-2 dark:border-white/15 dark:bg-zinc-900">
            <span className="font-semibold">Claim:</span> {result.claim}
          </p>
          <p className="inline-flex items-center gap-1 font-semibold uppercase tracking-wide text-zinc-600 dark:text-zinc-300">
            {verdictIcon(result.analysis.verdict)} {result.analysis.verdict} ({Math.round(result.analysis.confidence * 100)}%)
          </p>
          <p className="text-zinc-700 dark:text-zinc-200">{result.analysis.explanation}</p>
          <p className="rounded-lg bg-amber-50 p-2 text-zinc-700 dark:bg-amber-950/50 dark:text-zinc-200">
            <span className="font-semibold">Correction:</span> {result.analysis.correction}
          </p>
          {result.wiki ? (
            <div className="rounded-lg border border-black/10 bg-white p-2 dark:border-white/15 dark:bg-zinc-800">
              <p className="mb-1 font-semibold">Wikipedia: {result.wiki.title}</p>
              <p className="mb-2 text-zinc-700 dark:text-zinc-200">{result.wiki.extract}</p>
              <a
                href={result.wiki.contentUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 font-semibold text-blue-700 underline-offset-2 hover:underline dark:text-blue-300"
              >
                Open entry <ExternalLink size={11} />
              </a>
            </div>
          ) : null}
        </div>
      ) : (
        <p className="text-xs text-zinc-500">
          No check yet. Trigger from a log line or dialogue claim to inspect what the simulation gets right/wrong.
        </p>
      )}
    </Panel>
  );
}
