import { ExternalLink, MapPin, ShieldCheck } from "lucide-react";
import Panel from "./Panel";

export default function GalleryPanel({ records }) {
  return (
    <Panel
      title="County Gallery Tour"
      subtitle="Real exhibition and collection notes from Oxford/Lafayette research"
      className="h-full"
    >
      <div className="grid max-h-[70vh] gap-3 overflow-y-auto pr-1 md:grid-cols-2">
        {records.map((record) => (
          <article
            key={record.id}
            className="rounded-xl border border-black/10 bg-white/80 p-3 text-xs dark:border-white/15 dark:bg-zinc-800/70"
          >
            <p className="mb-1 text-sm font-semibold text-zinc-900 dark:text-zinc-100">{record.title}</p>
            <p className="mb-1 inline-flex items-center gap-1 text-zinc-600 dark:text-zinc-300">
              <MapPin size={12} /> {record.venue} • {record.location}
            </p>
            <p className="mb-2 text-zinc-700 dark:text-zinc-200">{record.summary}</p>
            <ul className="mb-2 list-disc space-y-1 pl-4 text-zinc-700 dark:text-zinc-200">
              {record.displayItems.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
            <p className="mb-2 inline-flex items-center gap-1 text-[11px] text-zinc-500 dark:text-zinc-400">
              <ShieldCheck size={11} /> Verified {record.verificationDate}
            </p>
            <a
              href={record.sourceUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 font-semibold text-blue-700 underline-offset-2 hover:underline dark:text-blue-300"
            >
              Visit source <ExternalLink size={11} />
            </a>
          </article>
        ))}
      </div>
    </Panel>
  );
}
