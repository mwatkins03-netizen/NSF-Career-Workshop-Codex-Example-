import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import Panel from "./Panel";

export default function GameLogPanel({ logs, onExportJson, onExportMarkdown }) {
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");

  const types = useMemo(() => ["all", ...new Set(logs.map((entry) => entry.type))], [logs]);

  const filtered = useMemo(() => {
    return logs.filter((entry) => {
      const matchesType = typeFilter === "all" || entry.type === typeFilter;
      const matchesQuery =
        !query.trim() ||
        entry.message.toLowerCase().includes(query.toLowerCase()) ||
        entry.type.toLowerCase().includes(query.toLowerCase());
      return matchesType && matchesQuery;
    });
  }, [logs, query, typeFilter]);

  return (
    <Panel
      title="Game Log"
      subtitle="Searchable, filterable, exportable"
      right={
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onExportJson}
            className="rounded-full border border-black/15 px-2.5 py-1 text-[10px] font-semibold dark:border-white/20"
          >
            Export JSON
          </button>
          <button
            type="button"
            onClick={onExportMarkdown}
            className="rounded-full border border-black/15 px-2.5 py-1 text-[10px] font-semibold dark:border-white/20"
          >
            Export MD
          </button>
        </div>
      }
    >
      <div className="mb-2 grid gap-2 sm:grid-cols-[1fr_auto]">
        <label className="relative block">
          <Search size={14} className="pointer-events-none absolute left-2 top-2.5 text-zinc-400" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search events"
            className="w-full rounded-lg border border-black/15 bg-white/90 py-2 pl-8 pr-3 text-xs outline-none ring-emerald-300 focus:ring-2 dark:border-white/20 dark:bg-zinc-800"
          />
        </label>
        <select
          value={typeFilter}
          onChange={(event) => setTypeFilter(event.target.value)}
          className="rounded-lg border border-black/15 bg-white/90 px-2 py-2 text-xs dark:border-white/20 dark:bg-zinc-800"
        >
          {types.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>
      </div>

      <div className="max-h-72 space-y-2 overflow-y-auto pr-1">
        {filtered.slice(0, 140).map((entry) => (
          <div key={entry.id} className="rounded-lg border border-black/10 bg-white/80 p-2 text-xs dark:border-white/15 dark:bg-zinc-800/80">
            <div className="mb-1 flex items-center justify-between gap-2 text-[10px] uppercase tracking-wide text-zinc-500 dark:text-zinc-400">
              <span>{entry.type}</span>
              <span>{entry.dayLabel}</span>
            </div>
            <p className="text-zinc-700 dark:text-zinc-200">{entry.message}</p>
          </div>
        ))}
        {!filtered.length ? <p className="text-xs text-zinc-500">No matching log entries.</p> : null}
      </div>
    </Panel>
  );
}
