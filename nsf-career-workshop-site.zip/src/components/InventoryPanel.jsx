import { Book, FileText } from "lucide-react";
import Panel from "./Panel";

export default function InventoryPanel({ items, activeBook, onRead, onCloseBook, busy }) {
  const books = items.filter((item) => item.readable);
  const active = items.find((item) => item.id === activeBook);

  return (
    <Panel title="Inventory" subtitle="Procedurally generated realistic objects">
      <div className="max-h-56 space-y-2 overflow-y-auto pr-1">
        {items.slice(0, 28).map((item) => (
          <div key={item.id} className="rounded-lg border border-black/10 bg-white/80 p-2 dark:border-white/15 dark:bg-zinc-800/80">
            <p className="text-xs font-semibold text-zinc-900 dark:text-zinc-100">{item.name}</p>
            <p className="text-[11px] text-zinc-600 dark:text-zinc-400">
              {item.year} • {item.provenance}
            </p>
            <div className="mt-2 flex gap-2">
              {item.readable ? (
                <button
                  type="button"
                  onClick={() => onRead(item.id)}
                  disabled={busy}
                  className="inline-flex items-center gap-1 rounded-full bg-zinc-900 px-2.5 py-1 text-[11px] font-semibold text-zinc-50 dark:bg-zinc-100 dark:text-zinc-900"
                >
                  <Book size={11} /> {item.generatedText ? "Open" : "Generate + Read"}
                </button>
              ) : (
                <span className="inline-flex items-center gap-1 rounded-full bg-zinc-200 px-2.5 py-1 text-[11px] text-zinc-700 dark:bg-zinc-700 dark:text-zinc-300">
                  <FileText size={11} /> Artifact
                </span>
              )}
            </div>
          </div>
        ))}
        {!items.length ? <p className="text-xs text-zinc-500">No items yet. Explore to populate inventory.</p> : null}
      </div>

      {active ? (
        <div className="mt-3 rounded-xl border border-black/10 bg-zinc-50 p-3 dark:border-white/20 dark:bg-zinc-900">
          <div className="mb-2 flex items-center justify-between gap-2">
            <p className="text-xs font-semibold">{active.name}</p>
            <button
              type="button"
              onClick={onCloseBook}
              className="rounded-full border border-black/15 px-2 py-1 text-[10px] dark:border-white/20"
            >
              Close
            </button>
          </div>
          <p className="max-h-40 overflow-y-auto whitespace-pre-line text-xs leading-relaxed text-zinc-700 dark:text-zinc-300">
            {active.generatedText || "No text generated."}
          </p>
        </div>
      ) : null}

      <p className="mt-3 text-[11px] text-zinc-500">Readable books discovered: {books.length}</p>
    </Panel>
  );
}
