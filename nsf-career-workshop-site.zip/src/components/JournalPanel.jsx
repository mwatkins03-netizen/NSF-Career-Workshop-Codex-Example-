import { useState } from "react";
import { NotebookPen } from "lucide-react";
import Panel from "./Panel";

export default function JournalPanel({ entries, onAdd }) {
  const [draft, setDraft] = useState("");

  return (
    <Panel title="Journal" subtitle="Record observations, motives, and evidence links">
      <form
        onSubmit={(event) => {
          event.preventDefault();
          if (!draft.trim()) return;
          onAdd(draft);
          setDraft("");
        }}
        className="mb-3 space-y-2"
      >
        <textarea
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          rows={4}
          placeholder="Write what happened, what you suspect, and which source might support it."
          className="w-full rounded-xl border border-black/15 bg-white/90 px-3 py-2 text-sm outline-none ring-emerald-300 focus:ring-2 dark:border-white/20 dark:bg-zinc-800"
        />
        <button
          type="submit"
          className="inline-flex items-center gap-1 rounded-full bg-zinc-900 px-3 py-1.5 text-xs font-semibold text-zinc-50 dark:bg-zinc-100 dark:text-zinc-900"
        >
          <NotebookPen size={13} /> Add Entry
        </button>
      </form>

      <div className="max-h-80 space-y-2 overflow-y-auto pr-1">
        {entries.map((entry) => (
          <article
            key={entry.id}
            className="rounded-lg border border-black/10 bg-white/85 p-3 text-xs dark:border-white/15 dark:bg-zinc-800/80"
          >
            <p className="mb-1 text-[10px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">
              Day {entry.day} • {entry.zoneId}
            </p>
            <p className="whitespace-pre-line leading-relaxed text-zinc-700 dark:text-zinc-200">{entry.text}</p>
          </article>
        ))}
        {!entries.length ? (
          <p className="text-xs text-zinc-500">No entries yet. Good historians write while memory is fresh.</p>
        ) : null}
      </div>
    </Panel>
  );
}
