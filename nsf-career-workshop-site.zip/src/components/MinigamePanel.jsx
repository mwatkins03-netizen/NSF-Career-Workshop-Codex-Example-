import Panel from "./Panel";

export default function MinigamePanel({ state, questions, onStart, onAnswer, onClose }) {
  if (!state.active) {
    return (
      <Panel title="Minigame: Archive Sprint" subtitle="Quick plausibility checks for bonus XP">
        <button
          type="button"
          onClick={onStart}
          className="rounded-full bg-zinc-900 px-3 py-1.5 text-xs font-semibold text-zinc-50 dark:bg-zinc-100 dark:text-zinc-900"
        >
          Start Minigame
        </button>
      </Panel>
    );
  }

  const question = questions[state.index];

  return (
    <Panel title="Minigame: Archive Sprint" subtitle={`Score ${state.score}/${questions.length}`}>
      <p className="mb-2 text-sm font-semibold">{question.prompt}</p>
      <div className="space-y-2">
        {question.choices.map((choice, idx) => (
          <button
            key={choice}
            type="button"
            onClick={() => onAnswer(idx)}
            disabled={state.completed}
            className="block w-full rounded-lg border border-black/12 bg-white px-3 py-2 text-left text-xs transition hover:border-zinc-700 disabled:opacity-60 dark:border-white/15 dark:bg-zinc-800"
          >
            {idx + 1}. {choice}
          </button>
        ))}
      </div>
      {state.feedback ? <p className="mt-3 text-xs text-zinc-600 dark:text-zinc-300">{state.feedback}</p> : null}
      {state.completed ? (
        <button
          type="button"
          onClick={onClose}
          className="mt-3 rounded-full bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-zinc-50"
        >
          Finish
        </button>
      ) : null}
    </Panel>
  );
}
