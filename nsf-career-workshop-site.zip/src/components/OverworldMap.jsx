import { OVERWORLD_ASCII, ZONES } from "../constants/world";
import Panel from "./Panel";

export default function OverworldMap({ currentZoneId, neighbors, onTravel }) {
  const neighborSet = new Set(neighbors.map((zone) => zone.id));

  return (
    <Panel
      title="Overworld Map"
      subtitle="ASCII topography with connected travel nodes"
      className="h-full"
    >
      <pre className="mb-3 overflow-x-auto rounded-xl border border-black/10 bg-zinc-950 p-3 font-mono text-[11px] leading-relaxed text-emerald-300 shadow-inner dark:border-white/10">
        {OVERWORLD_ASCII}
      </pre>

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {ZONES.map((zone) => {
          const isCurrent = zone.id === currentZoneId;
          const isNeighbor = neighborSet.has(zone.id);
          return (
            <button
              key={zone.id}
              type="button"
              onClick={() => onTravel(zone.id)}
              disabled={!isCurrent && !isNeighbor}
              className={`rounded-xl border px-3 py-2 text-left text-xs transition ${
                isCurrent
                  ? "border-emerald-500 bg-emerald-100/90 text-emerald-900 dark:bg-emerald-900/50 dark:text-emerald-100"
                  : isNeighbor
                    ? "border-black/15 bg-white/90 hover:border-emerald-400 hover:bg-emerald-50 dark:border-white/20 dark:bg-zinc-800 dark:hover:bg-zinc-700"
                    : "cursor-not-allowed border-black/8 bg-zinc-100 text-zinc-500 dark:border-white/10 dark:bg-zinc-900 dark:text-zinc-600"
              }`}
            >
              <p className="font-semibold">{zone.name}</p>
              <p className="opacity-80">{zone.zoneType}</p>
            </button>
          );
        })}
      </div>
    </Panel>
  );
}
