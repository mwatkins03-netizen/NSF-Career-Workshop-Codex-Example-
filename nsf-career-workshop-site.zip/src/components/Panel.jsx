export default function Panel({ title, subtitle, right, className = "", children }) {
  return (
    <section
      className={`rounded-2xl border border-black/10 bg-white/75 p-4 shadow-aura backdrop-blur dark:border-white/15 dark:bg-zinc-900/65 ${className}`}
    >
      <header className="mb-3 flex items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-lg font-semibold tracking-wide text-zinc-900 dark:text-zinc-100">{title}</h3>
          {subtitle ? <p className="text-xs text-zinc-600 dark:text-zinc-400">{subtitle}</p> : null}
        </div>
        {right}
      </header>
      {children}
    </section>
  );
}
