import { ExternalLink, LibraryBig } from "lucide-react";
import Panel from "./Panel";

export default function PrimarySourcesPanel({ sources }) {
  return (
    <Panel title="Primary Source Desk" subtitle="Real historical records unlocked through exploration">
      <div className="max-h-64 space-y-3 overflow-y-auto pr-1">
        {sources.map((source) => (
          <article
            key={source.id}
            className="rounded-xl border border-black/10 bg-white/85 p-3 dark:border-white/15 dark:bg-zinc-800/80"
          >
            <p className="mb-1 inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wider text-zinc-600 dark:text-zinc-300">
              <LibraryBig size={12} /> {source.year}
            </p>
            <p className="text-sm font-semibold text-zinc-900 dark:text-zinc-100">{source.title}</p>
            <p className="mt-2 text-xs italic leading-relaxed text-zinc-700 dark:text-zinc-200">"{source.quote}"</p>
            <a
              href={source.url}
              target="_blank"
              rel="noreferrer"
              className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-blue-700 underline-offset-2 hover:underline dark:text-blue-300"
            >
              Source link <ExternalLink size={11} />
            </a>
          </article>
        ))}
        {!sources.length ? <p className="text-xs text-zinc-500">No sources unlocked yet.</p> : null}
      </div>
    </Panel>
  );
}
