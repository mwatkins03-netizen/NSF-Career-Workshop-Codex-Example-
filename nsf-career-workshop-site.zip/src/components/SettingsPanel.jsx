import Panel from "./Panel";

export default function SettingsPanel({ preferences, onChange, onReset, onDebugXp, onDebugEvent, onDebugGameOver }) {
  return (
    <Panel title="Settings & Testing" subtitle="Customize visuals, mechanics, and LLM integrations">
      <div className="grid gap-3 md:grid-cols-2">
        <label className="text-xs">
          Theme
          <select
            value={preferences.theme}
            onChange={(event) => onChange({ theme: event.target.value })}
            className="mt-1 w-full rounded-lg border border-black/15 bg-white px-2 py-2 text-xs dark:border-white/20 dark:bg-zinc-800"
          >
            <option value="light">Light</option>
            <option value="dark">Dark</option>
          </select>
        </label>

        <label className="text-xs">
          Animation Intensity
          <select
            value={preferences.animationLevel}
            onChange={(event) => onChange({ animationLevel: event.target.value })}
            className="mt-1 w-full rounded-lg border border-black/15 bg-white px-2 py-2 text-xs dark:border-white/20 dark:bg-zinc-800"
          >
            <option value="subtle">Subtle</option>
            <option value="normal">Normal</option>
            <option value="vivid">Vivid</option>
          </select>
        </label>

        <label className="text-xs">
          Difficulty
          <select
            value={preferences.difficulty}
            onChange={(event) => onChange({ difficulty: event.target.value })}
            className="mt-1 w-full rounded-lg border border-black/15 bg-white px-2 py-2 text-xs dark:border-white/20 dark:bg-zinc-800"
          >
            <option value="relaxed">Relaxed</option>
            <option value="standard">Standard</option>
            <option value="severe">Severe</option>
          </select>
        </label>

        <label className="mt-4 flex items-center gap-2 text-xs">
          <input
            type="checkbox"
            checked={preferences.autoFactCheck}
            onChange={(event) => onChange({ autoFactCheck: event.target.checked })}
          />
          Auto fact-check NPC replies
        </label>

        <label className="mt-4 flex items-center gap-2 text-xs">
          <input
            type="checkbox"
            checked={preferences.wikiIntegration}
            onChange={(event) => onChange({ wikiIntegration: event.target.checked })}
          />
          Wikipedia integration
        </label>

        <label className="mt-4 flex items-center gap-2 text-xs">
          <input
            type="checkbox"
            checked={preferences.llm.enabled}
            onChange={(event) => onChange({ llm: { enabled: event.target.checked } })}
          />
          Enable LLM agents
        </label>
      </div>

      <div className="mt-3 grid gap-2 md:grid-cols-2">
        <label className="text-xs">
          OpenAI API key (stored locally)
          <input
            type="password"
            value={preferences.llm.apiKey}
            onChange={(event) => onChange({ llm: { apiKey: event.target.value } })}
            className="mt-1 w-full rounded-lg border border-black/15 bg-white px-2 py-2 text-xs dark:border-white/20 dark:bg-zinc-800"
          />
        </label>
        <label className="text-xs">
          Model
          <input
            type="text"
            value={preferences.llm.model}
            onChange={(event) => onChange({ llm: { model: event.target.value } })}
            className="mt-1 w-full rounded-lg border border-black/15 bg-white px-2 py-2 text-xs dark:border-white/20 dark:bg-zinc-800"
          />
        </label>
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <button
          type="button"
          onClick={onDebugXp}
          className="rounded-full border border-black/20 px-3 py-1.5 text-xs font-semibold dark:border-white/25"
        >
          Debug +150 XP
        </button>
        <button
          type="button"
          onClick={onDebugEvent}
          className="rounded-full border border-black/20 px-3 py-1.5 text-xs font-semibold dark:border-white/25"
        >
          Debug Event
        </button>
        <button
          type="button"
          onClick={onDebugGameOver}
          className="rounded-full border border-black/20 px-3 py-1.5 text-xs font-semibold dark:border-white/25"
        >
          Debug Game Over
        </button>
        <button
          type="button"
          onClick={() => onReset()}
          className="rounded-full border border-rose-400 px-3 py-1.5 text-xs font-semibold text-rose-700 dark:border-rose-700 dark:text-rose-300"
        >
          Reset Run
        </button>
      </div>
    </Panel>
  );
}
