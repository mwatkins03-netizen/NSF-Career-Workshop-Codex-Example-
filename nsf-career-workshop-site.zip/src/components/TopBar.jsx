import { MoonStar, Save, Sun, Upload } from "lucide-react";

const TABS = [
  { id: "play", label: "Play" },
  { id: "journal", label: "Journal" },
  { id: "gallery", label: "Gallery" },
  { id: "faq", label: "FAQ" },
  { id: "about", label: "About" },
  { id: "settings", label: "Settings" }
];

export default function TopBar({
  activeTab,
  onTab,
  preferences,
  onToggleTheme,
  onMoon,
  onSave,
  onExport,
  level,
  day
}) {
  return (
    <header className="sticky top-0 z-40 border-b border-black/10 bg-parchment/85 px-4 py-3 backdrop-blur dark:border-white/10 dark:bg-coal/85">
      <div className="mx-auto flex w-full max-w-[1400px] flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-center gap-3">
          <div className="animate-floaty rounded-full border border-black/20 bg-white/80 px-3 py-1 font-display text-sm font-semibold tracking-wide text-zinc-800 dark:border-white/20 dark:bg-zinc-900 dark:text-zinc-100">
            Yokna Ledger
          </div>
          <p className="text-xs uppercase tracking-[0.14em] text-zinc-600 dark:text-zinc-400">Day {day} • Lv {level}</p>
        </div>

        <nav className="flex flex-wrap gap-2">
          {TABS.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTab(tab.id)}
              className={`rounded-full px-3 py-1.5 text-sm transition ${
                activeTab === tab.id
                  ? "bg-zinc-900 text-zinc-50 dark:bg-zinc-100 dark:text-zinc-900"
                  : "bg-white/80 text-zinc-700 hover:bg-white dark:bg-zinc-800/80 dark:text-zinc-200 dark:hover:bg-zinc-700"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onSave}
            className="inline-flex items-center gap-1 rounded-full border border-black/15 bg-white/90 px-3 py-1.5 text-xs font-semibold text-zinc-800 transition hover:bg-white dark:border-white/20 dark:bg-zinc-800 dark:text-zinc-100 dark:hover:bg-zinc-700"
          >
            <Save size={14} /> Save
          </button>
          <button
            type="button"
            onClick={onExport}
            className="inline-flex items-center gap-1 rounded-full border border-black/15 bg-white/90 px-3 py-1.5 text-xs font-semibold text-zinc-800 transition hover:bg-white dark:border-white/20 dark:bg-zinc-800 dark:text-zinc-100 dark:hover:bg-zinc-700"
          >
            <Upload size={14} /> Export
          </button>
          <button
            type="button"
            onClick={() => {
              onToggleTheme(preferences.theme === "dark" ? "light" : "dark");
              onMoon();
            }}
            className="rounded-full border border-black/20 bg-white/90 p-2 text-zinc-800 transition hover:scale-105 dark:border-white/30 dark:bg-zinc-800 dark:text-zinc-100"
            title="Theme + easter egg counter"
          >
            {preferences.theme === "dark" ? <Sun size={16} /> : <MoonStar size={16} />}
          </button>
        </div>
      </div>
    </header>
  );
}
