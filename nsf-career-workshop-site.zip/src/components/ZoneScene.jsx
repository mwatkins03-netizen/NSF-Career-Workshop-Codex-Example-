import { BookOpen, Eye, Sparkles } from "lucide-react";
import Panel from "./Panel";

export default function ZoneScene({ zone, onExplore, primarySourcesCount, discoveredBooks }) {
  return (
    <Panel
      title={zone.name}
      subtitle={`${zone.zoneType} zone • Risk ${zone.risk}/5`}
      right={
        <button
          type="button"
          onClick={onExplore}
          className="inline-flex items-center gap-2 rounded-full bg-brick px-3 py-1.5 text-xs font-semibold text-zinc-50 transition hover:brightness-110"
        >
          <Eye size={14} /> Explore
        </button>
      }
      className="h-full"
    >
      <div className="grid gap-3 lg:grid-cols-[1.2fr_0.8fr]">
        <div style={{ perspective: 900 }}>
          <pre
            className="animate-pulseGrid overflow-x-auto rounded-xl border border-black/10 bg-zinc-950 p-3 font-mono text-[12px] leading-relaxed text-sky-200 dark:border-white/10"
            style={{ transform: "rotateX(10deg) rotateY(-1.5deg)" }}
          >
            {zone.ascii.join("\n")}
          </pre>
        </div>

        <div className="space-y-3 rounded-xl border border-black/10 bg-white/70 p-3 text-sm dark:border-white/15 dark:bg-zinc-900/60">
          <p className="text-zinc-700 dark:text-zinc-300">{zone.description}</p>
          <div className="rounded-lg bg-zinc-100/90 p-2 text-xs text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300">
            <p className="mb-1 inline-flex items-center gap-1 font-semibold text-zinc-800 dark:text-zinc-100">
              <Sparkles size={13} /> Current Discovery Pulse
            </p>
            <p>Primary sources unlocked: {primarySourcesCount}</p>
            <p>Readable books found: {discoveredBooks}</p>
          </div>
          <div className="rounded-lg border border-black/10 bg-white p-2 text-xs dark:border-white/20 dark:bg-zinc-800">
            <p className="inline-flex items-center gap-1 font-semibold">
              <BookOpen size={13} /> Hint
            </p>
            <p>Explore, then read found books to deepen journal quality and assessment scores.</p>
          </div>
        </div>
      </div>
    </Panel>
  );
}
