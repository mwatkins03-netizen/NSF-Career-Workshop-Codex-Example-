export const ABOUT_MARKDOWN = `
# About Yokna Ledger

**Yokna Ledger** is a historically grounded roguelike RPG that explores social life, archives, rhetoric, and reputation in a Faulkner-inspired county modelled on Lafayette County, Mississippi.

## Design Goals

- Keep the core loop simple: travel, investigate, converse, duel, record.
- Let complexity emerge through social consequences and documentation.
- Reward historically grounded choices without flattening moral ambiguity.
- Treat the player as both participant and recorder of county history.

## Educational Spine

Primary sources, documented exhibition research, and a fact-check panel are integrated into play. The game intentionally separates **fictional character roleplay** from **historical veracity checks**.

## Disclaimer

This simulation includes fictional literary characters and historically sensitive themes. It is educational software, not a substitute for archival scholarship.
`;

export const FAQ_ITEMS = [
  {
    q: "Is this historically accurate if Yoknapatawpha is fictional?",
    a: "The character layer is literary fiction; the law, documents, social context, and gallery research layers are tied to real sources and explicitly fact-checked."
  },
  {
    q: "How does the duel system work?",
    a: "Duel rounds are rhetorical exchanges. You choose moves like allusion, jibe, rumor, or quote-backed riposte. Composure reaches zero and the loser yields the floor."
  },
  {
    q: "Where are the primary sources from?",
    a: "From public historical records and official archives, including the Mississippi Constitution PDF, U.S. National Archives milestone documents, Nobel speech text, Library of Congress material, and Census documentation."
  },
  {
    q: "Can I play without an API key?",
    a: "Yes. The game ships with deterministic local generation. LLM features are optional and can be enabled in Settings for dynamic NPC roleplay and fact-checking."
  },
  {
    q: "How do saves and transcripts work?",
    a: "Autosave runs in localStorage. You can manually save snapshots and export a full gameplay transcript/game log as JSON or Markdown from the log panel."
  },
  {
    q: "What does the assessment layer score?",
    a: "It scores historical grounding, social outcomes, documentation quality, and consistency between your actions and your journal. Then it produces a short, mildly sarcastic summary."
  }
];
