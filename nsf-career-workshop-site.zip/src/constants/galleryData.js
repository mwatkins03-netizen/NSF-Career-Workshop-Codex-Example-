export const GALLERY_RESEARCH_NOTES = [
  {
    id: "um-exhibitions-page",
    title: "University of Mississippi Museum - Exhibitions",
    venue: "University of Mississippi Museum",
    location: "Oxford, Mississippi",
    displayItems: [
      "Knowledge in Bloom, Diversity in Flight",
      "Art Faculty Show",
      "Chronicles of Luster Willis' American South",
      "Buie and Skipwith; Sisters, Artists, Collectors",
      "The Walter P. and Florence Lewisohn Caribbean Art Collection"
    ],
    summary:
      "The official exhibitions page lists rotating shows spanning university art practice, regional history, and collection-based interpretation.",
    sourceUrl: "https://olemiss.edu/museum/exhibitions/",
    verificationDate: "2026-03-19",
    sourceType: "official museum site"
  },
  {
    id: "um-sculpture-trail",
    title: "University of Mississippi Museum Sculpture Trail",
    venue: "University of Mississippi Museum / Yokna Sculpture Trail",
    location: "Oxford, Mississippi",
    displayItems: [
      "Rotating outdoor sculpture program",
      "18 large-scale sculptures (rotating)",
      "Collaboration with City of Oxford and Yoknapatawpha Arts Council"
    ],
    summary:
      "The museum documents a rotating outdoor sculpture trail tied to the broader Yokna public art initiative.",
    sourceUrl: "https://museum.olemiss.edu/university-of-mississippi-museum-sculpture-trail/",
    verificationDate: "2026-03-19",
    sourceType: "official museum post"
  },
  {
    id: "southside-exhibits",
    title: "SouthSide Gallery Exhibits",
    venue: "SouthSide Gallery",
    location: "Oxford Square, Mississippi",
    displayItems: [
      "Living Things (Jerrod Partridge)",
      "Rowan Oak Fifty Years Later: The Photography of Bill Connell",
      "Red Christmas",
      "A View From Two"
    ],
    summary:
      "SouthSide publishes a long-running exhibition archive with artist-specific monthly and seasonal shows.",
    sourceUrl: "https://www.southsideartgallery.com/exhibits",
    verificationDate: "2026-03-19",
    sourceType: "gallery archive"
  },
  {
    id: "southside-living-things",
    title: "Living Things by Jerrod Partridge",
    venue: "SouthSide Gallery",
    location: "Oxford Square, Mississippi",
    displayItems: [
      "Three Graces (oil on panel)",
      "Sari (oil on canvas)",
      "An Arrangement of Things (oil on canvas)"
    ],
    summary:
      "The exhibition page includes object-level listings and dimensions for works shown in Oxford.",
    sourceUrl: "https://www.southsideartgallery.com/exhibits/livingthings",
    verificationDate: "2026-03-19",
    sourceType: "gallery exhibition page"
  },
  {
    id: "rowan-oak-site",
    title: "Rowan Oak Historic House",
    venue: "Rowan Oak",
    location: "916 Old Taylor Rd, Oxford, MS",
    displayItems: [
      "Historic Faulkner home interior",
      "Grounds and outbuildings",
      "Seasonal access to literary heritage spaces"
    ],
    summary:
      "The Rowan Oak site provides official visitor information and contextual interpretation for Faulkner's home and grounds.",
    sourceUrl: "https://www.rowanoak.com/",
    verificationDate: "2026-03-19",
    sourceType: "official historic-house site"
  },
  {
    id: "museum-and-historic-houses",
    title: "Museum and Historic Houses Overview",
    venue: "University of Mississippi Museum and Historic Houses",
    location: "Oxford, Mississippi",
    displayItems: [
      "Southern folk art",
      "Greek and Roman antiquities",
      "19th century scientific instruments",
      "American fine art"
    ],
    summary:
      "The museum overview describes major holdings and identifies Rowan Oak as part of the same institutional complex.",
    sourceUrl: "https://olemiss.edu/museum/",
    verificationDate: "2026-03-19",
    sourceType: "institutional overview"
  }
];

export const GALLERY_BY_ID = Object.fromEntries(GALLERY_RESEARCH_NOTES.map((item) => [item.id, item]));
