export const DUEL_MOVES = [
  {
    id: "allusion-barrage",
    name: "Allusion Barrage",
    family: "allusion",
    flavor: "Invoke a chain of literary references faster than your opponent can untangle.",
    power: 16,
    accuracy: 0.88,
    status: "flustered",
    statusChance: 0.25
  },
  {
    id: "snide-jibe",
    name: "Snide Jibe",
    family: "jibe",
    flavor: "A precise insult aimed at social pretension.",
    power: 14,
    accuracy: 0.94,
    status: "rattled",
    statusChance: 0.2
  },
  {
    id: "gossip-drop",
    name: "Gossip Drop",
    family: "rumor",
    flavor: "Reveal strategically incomplete town gossip.",
    power: 15,
    accuracy: 0.85,
    status: "discredited",
    statusChance: 0.22
  },
  {
    id: "polite-innuendo",
    name: "Polite Innuendo",
    family: "innuendo",
    flavor: "Say little, imply everything.",
    power: 13,
    accuracy: 0.95,
    status: "off-balance",
    statusChance: 0.18
  },
  {
    id: "quoted-riposte",
    name: "Quoted Riposte",
    family: "poise",
    flavor: "Counter with a primary source quotation and dry composure.",
    power: 12,
    accuracy: 0.98,
    status: "chastened",
    statusChance: 0.15
  }
];

export const PROCEDURAL_ITEM_TYPES = [
  "newspaper clipping",
  "receipt",
  "train ticket",
  "deed copy",
  "church bulletin",
  "court summons",
  "postcard",
  "book",
  "field notebook",
  "seed invoice",
  "matchbook",
  "scribbled map"
];

export const BOOK_TOPICS = [
  "tenant farming account records",
  "county courtroom anecdotes",
  "river trade logistics",
  "Mississippi constitutional debates",
  "Oxford social columns",
  "agricultural extension circulars",
  "public health bulletins",
  "rail timetable histories"
];

export const HARD_CODED_EVENTS = [
  {
    id: "ledger-dispute",
    title: "Ledger Dispute at Noon",
    trigger: (state) => state.day >= 2 && !state.flags.ledgerDisputeSeen,
    summary: "Two merchants argue over a penciled correction in the county ledger.",
    choices: [
      {
        text: "Inspect the handwriting and mediate.",
        effects: { xp: 24, reputation: 1, suspicion: -1, flag: "ledgerDisputeSeen" },
        result: "Your neat forensic eye calms the quarrel, though both men decide you're now a convenient witness."
      },
      {
        text: "Spread both versions and see what sticks.",
        effects: { xp: 14, reputation: -1, scandal: 1, flag: "ledgerDisputeSeen" },
        result: "By supper everyone knows three stories and none of them flatter you."
      },
      {
        text: "Decline involvement and move on.",
        effects: { xp: 8, suspicion: 1, flag: "ledgerDisputeSeen" },
        result: "Neutrality keeps your hands clean and your conscience mildly annoyed."
      }
    ]
  },
  {
    id: "flood-warning",
    title: "Levee Warning",
    trigger: (state) => state.zoneId === "river-landing" && state.day >= 4 && !state.flags.floodWarningSeen,
    summary: "A river bulletin predicts rising water and supply delays.",
    choices: [
      {
        text: "Help post notices and move goods uphill.",
        effects: { xp: 28, reputation: 2, fatigue: 1, flag: "floodWarningSeen" },
        result: "You spend an honest afternoon hauling crates and gain unglamorous respect."
      },
      {
        text: "Hoard supplies for later barter.",
        effects: { xp: 18, reputation: -2, scandal: 1, flag: "floodWarningSeen" },
        result: "Profitable, yes. Popular, no."
      },
      {
        text: "Interview dockhands for your journal instead.",
        effects: { xp: 21, journalPrompt: "flood voices", flag: "floodWarningSeen" },
        result: "You gain testimony that reads better than policy and helps fewer people."
      }
    ]
  },
  {
    id: "gallery-donor",
    title: "A Donor with Conditions",
    trigger: (state) => state.zoneId === "gallery-hall" && state.day >= 3 && !state.flags.galleryDonorSeen,
    summary: "A wealthy donor offers artifacts only if labels avoid awkward local history.",
    choices: [
      {
        text: "Reject censorship and keep labels intact.",
        effects: { xp: 30, reputation: 2, suspicion: 1, flag: "galleryDonorSeen" },
        result: "Funding slips away, but the labels keep their backbone."
      },
      {
        text: "Accept the gift and soften the labels.",
        effects: { xp: 20, reputation: -1, scandal: 2, flag: "galleryDonorSeen" },
        result: "The cases look fuller while your conscience gets oddly drafty."
      },
      {
        text: "Negotiate a temporary compromise and public forum.",
        effects: { xp: 26, reputation: 1, flag: "galleryDonorSeen" },
        result: "You buy time and earn the special distrust reserved for mediators."
      }
    ]
  }
];

export const MINIGAME_QUESTIONS = [
  {
    id: "mg1",
    prompt: "Which archive clue is most historically plausible for 1930s Lafayette County?",
    choices: [
      "A county tax receipt stamped by hand with fading purple ink",
      "A QR-coded digital permit from the sheriff",
      "A laminated plastic bus pass with barcode"],
    answerIndex: 0,
    rationale: "Paper receipts and manual stamps were common; modern digital systems were not."
  },
  {
    id: "mg2",
    prompt: "Which exhibition label best matches museum practice?",
    choices: [
      "Object, date, medium, provenance note, and interpretive context",
      "Just a dramatic nickname and no source",
      "Only a social media handle and emoji rating"],
    answerIndex: 0,
    rationale: "Museum labels prioritize documented provenance and context."
  },
  {
    id: "mg3",
    prompt: "In a Belle Epoque-style duel of wits, what usually wins?",
    choices: [
      "Well-timed allusion with verifiable evidence",
      "Volume alone",
      "Invented citations"],
    answerIndex: 0,
    rationale: "The game rewards proof-backed rhetoric over bluster."
  }
];
