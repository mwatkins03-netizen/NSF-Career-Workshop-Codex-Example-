export const PRIMARY_SOURCES = [
  {
    id: "ms-constitution-preamble-1890",
    year: 1890,
    title: "Constitution of the State of Mississippi, Preamble",
    quote:
      "We, the people of Mississippi in convention assembled, grateful to Almighty God, and invoking his blessing on our work, do ordain and establish this constitution.",
    sourceName: "Mississippi Secretary of State",
    url: "https://www.sos.ms.gov/content/documents/ed_pubs/pubs/Mississippi_Constitution.pdf",
    category: "law",
    tags: ["mississippi", "constitution", "state"]
  },
  {
    id: "ms-constitution-sec5-1890",
    year: 1890,
    title: "Mississippi Constitution, Article 3, Section 5",
    quote:
      "All political power is vested in, and derived from, the people; all government of right originates with the people, is founded upon their will only, and is instituted solely for the good of the whole.",
    sourceName: "Mississippi Secretary of State",
    url: "https://www.sos.ms.gov/content/documents/ed_pubs/pubs/Mississippi_Constitution.pdf",
    category: "law",
    tags: ["bill-of-rights", "civics"]
  },
  {
    id: "ms-constitution-sec7-1890",
    year: 1890,
    title: "Mississippi Constitution, Article 3, Section 7",
    quote:
      "The right to withdraw from the Federal Union on account of any real or supposed grievance, shall never be assumed by this state...",
    sourceName: "Mississippi Secretary of State",
    url: "https://www.sos.ms.gov/content/documents/ed_pubs/pubs/Mississippi_Constitution.pdf",
    category: "law",
    tags: ["reconstruction", "federal-union"]
  },
  {
    id: "emancipation-1863",
    year: 1863,
    title: "Emancipation Proclamation",
    quote:
      "...that all persons held as slaves within said designated States, and parts of States, are, and henceforward shall be free...",
    sourceName: "U.S. National Archives",
    url: "https://www.archives.gov/historical-docs/emancipation-proclamation/",
    category: "federal document",
    tags: ["slavery", "civil-war", "freedom"]
  },
  {
    id: "13th-amendment-1865",
    year: 1865,
    title: "13th Amendment, Section 1",
    quote:
      "Neither slavery nor involuntary servitude, except as a punishment for crime whereof the party shall have been duly convicted, shall exist within the United States...",
    sourceName: "U.S. Constitution",
    url: "https://www.archives.gov/milestone-documents/13th-amendment",
    category: "constitutional",
    tags: ["reconstruction", "law", "labor"]
  },
  {
    id: "faulkner-nobel-1950-a",
    year: 1950,
    title: "William Faulkner, Nobel Banquet Speech",
    quote: "I decline to accept the end of man.",
    sourceName: "Nobel Prize",
    url: "https://www.nobelprize.org/prizes/literature/1949/faulkner/speech/",
    category: "speech",
    tags: ["faulkner", "literature", "cold-war-era"]
  },
  {
    id: "faulkner-nobel-1950-b",
    year: 1950,
    title: "William Faulkner, Nobel Banquet Speech",
    quote: "I believe that man will not merely endure: he will prevail.",
    sourceName: "Nobel Prize",
    url: "https://www.nobelprize.org/prizes/literature/1949/faulkner/speech/",
    category: "speech",
    tags: ["faulkner", "humanism"]
  },
  {
    id: "fourteenth-amendment-1868",
    year: 1868,
    title: "14th Amendment, Section 1",
    quote:
      "No State shall make or enforce any law which shall abridge the privileges or immunities of citizens of the United States...",
    sourceName: "U.S. Constitution",
    url: "https://www.archives.gov/milestone-documents/14th-amendment",
    category: "constitutional",
    tags: ["citizenship", "due-process"]
  },
  {
    id: "1940-census-civic-duty",
    year: 1940,
    title: "1940 Census Enumerator Training",
    quote: "This video gives an overview of the 1940 census and emphasizes the responsibility of all citizens to participate.",
    sourceName: "U.S. National Archives",
    url: "https://www.archives.gov/research/census/1940/videos.html",
    category: "census",
    tags: ["demography", "state-capacity", "method"]
  },
  {
    id: "census-questionnaires",
    year: 1940,
    title: "Decennial Census Questionnaires and Instructions",
    quote: "Many of our surveys now offer an online response in place of completing and mailing a printed form.",
    sourceName: "U.S. Census Bureau",
    url: "https://www.census.gov/programs-surveys/decennial-census/technical-documentation/questionnaires.2010_Census.html",
    category: "census",
    tags: ["method", "questionnaire", "longitudinal"]
  },
  {
    id: "ms-bill-rights-assembly",
    year: 1890,
    title: "Mississippi Constitution, Article 3, Section 11",
    quote: "The right of the people peaceably to assemble and petition the government on any subject shall never be impaired.",
    sourceName: "Mississippi Secretary of State",
    url: "https://www.sos.ms.gov/content/documents/ed_pubs/pubs/Mississippi_Constitution.pdf",
    category: "law",
    tags: ["assembly", "rights"]
  },
  {
    id: "gettysburg-1863",
    year: 1863,
    title: "Gettysburg Address",
    quote: "...that government of the people, by the people, for the people, shall not perish from the earth.",
    sourceName: "Library of Congress",
    url: "https://www.loc.gov/exhibits/gadd/gadrft.html",
    category: "speech",
    tags: ["civil-war", "civic-language"]
  }
];

export const PRIMARY_SOURCE_BY_ID = Object.fromEntries(PRIMARY_SOURCES.map((src) => [src.id, src]));
