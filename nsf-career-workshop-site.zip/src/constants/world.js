export const GAME_TITLE = "Yokna Ledger";

export const LEVEL_THRESHOLDS = [0, 120, 280, 520, 860, 1280, 1820, 2500, 3400];

export const GAME_OVER_RULES = {
  scandalLimit: 8,
  exhaustionLimit: 12,
  suspicionLimit: -8,
  prestigeWinLevel: 7,
  prestigeWinArchives: 12,
  maxDays: 20
};

export const STARTING_STATS = {
  wit: 3,
  poise: 3,
  curiosity: 4,
  stamina: 5,
  reputation: 0
};

export const OVERWORLD_ASCII = `
                 ▲ BAILEY WOODS
                / \\
               /   \\
    OLD FRENCHMAN'S BEND --- JEFFERSON SQUARE --- ROWAN OAK
             \\              |              /
              \\        COURTHOUSE      /
               \\           |         /
                 ------ RIVER LEVEE ----
`;

export const ZONES = [
  {
    id: "jefferson-square",
    name: "Jefferson Square",
    zoneType: "Civic",
    risk: 2,
    neighbors: ["courthouse-records", "river-landing", "rowan-oak"],
    npcs: ["gavin-stevens", "vk-ratliff", "deacon-trott"],
    description:
      "Merchants, courthouse men, and rumor-mongers cross paths in a hot square of brick, dust, and public opinion.",
    ascii: [
      "╭─────────────────────────────────────╮",
      "│  ███  COUNTY LEDGER OFFICE  ███    │",
      "│  ║║║   gossip stalls hum     ║║║    │",
      "│ [coach]  [dry goods]  [cafe]        │",
      "│     folks trading news at noon      │",
      "╰─────────────────────────────────────╯"
    ]
  },
  {
    id: "courthouse-records",
    name: "Courthouse Records Room",
    zoneType: "Archive",
    risk: 3,
    neighbors: ["jefferson-square", "gallery-hall"],
    npcs: ["clerk-snopes", "temple-drake"],
    description:
      "Dusty deed books, tax rolls, and summonses: here the county writes itself, one formal line at a time.",
    ascii: [
      "╭─────────────────────────────────────╮",
      "│   ║║  deed ledgers stacked to rafters",
      "│  ╔╬╬╗ card catalog + ink well      │",
      "│  ╚╬╬╝ whisper: \"check section 241\" │",
      "│  courthouse bell rings each hour   │",
      "╰─────────────────────────────────────╯"
    ]
  },
  {
    id: "rowan-oak",
    name: "Rowan Oak Grounds",
    zoneType: "Domestic",
    risk: 1,
    neighbors: ["jefferson-square", "bailey-woods"],
    npcs: ["william-faulkner-shadow", "dilsey-gibson", "quentin-compson"],
    description:
      "The house and its woods hold drafts, debts, dogs, and drafts again. You can feel the sentences pacing.",
    ascii: [
      "╭─────────────────────────────────────╮",
      "│         ┌───────────────┐          │",
      "│   trees │    ROWAN OAK  │ porch    │",
      "│  /\/\/\ │ wall outline  │ lamp     │",
      "│  trail  └───────────────┘ desk     │",
      "╰─────────────────────────────────────╯"
    ]
  },
  {
    id: "bailey-woods",
    name: "Bailey Woods Trail",
    zoneType: "Outdoors",
    risk: 2,
    neighbors: ["rowan-oak", "old-frenchmans-bend"],
    npcs: ["sam-fathers", "boon-hogganbeck"],
    description:
      "Pine and oak shade the trail. Hunters, students, and storytellers all claim they know the old paths.",
    ascii: [
      "╭─────────────────────────────────────╮",
      "│  /\   /\   /\   /\   /\   /\       │",
      "│ /__\ /__\ /__\ /__\ /__\ /__\      │",
      "│   deer sign • boot tracks • rain    │",
      "│   hush: every twig sounds historic  │",
      "╰─────────────────────────────────────╯"
    ]
  },
  {
    id: "old-frenchmans-bend",
    name: "Old Frenchman's Bend",
    zoneType: "Agrarian",
    risk: 4,
    neighbors: ["bailey-woods", "river-landing"],
    npcs: ["flem-snopes", "ike-mccaslin"],
    description:
      "Fields, tenant cabins, mules, and negotiations: money, weather, and hierarchy decide the pace here.",
    ascii: [
      "╭─────────────────────────────────────╮",
      "│    barn ┌──────┐   corn rows        │",
      "│  mule   │ gin  │  :::::::::::       │",
      "│ cabin   └──────┘  :::::::::::       │",
      "│ rumor travels faster than wagons    │",
      "╰─────────────────────────────────────╯"
    ]
  },
  {
    id: "river-landing",
    name: "River Landing and Levee",
    zoneType: "Transit",
    risk: 3,
    neighbors: ["old-frenchmans-bend", "jefferson-square", "gallery-hall"],
    npcs: ["wash-jones", "newsboy-carter"],
    description:
      "Freight, cotton bales, and politics meet the river. Flood memory and commerce both run deep.",
    ascii: [
      "╭─────────────────────────────────────╮",
      "│ ~~~  barge wake ~~~  levee wall     │",
      "│ crates [cotton][seed][newspapers]   │",
      "│ lamp post flicker / train whistle   │",
      "│ dockhands trading bets and headlines│",
      "╰─────────────────────────────────────╯"
    ]
  },
  {
    id: "gallery-hall",
    name: "County Gallery Hall",
    zoneType: "Museum",
    risk: 1,
    neighbors: ["courthouse-records", "river-landing"],
    npcs: ["curator-hollis", "student-guide"],
    description:
      "A rotating civic gallery blending university, square, and sculpture-trail exhibitions with local archives.",
    ascii: [
      "╭─────────────────────────────────────╮",
      "│ [frame] [text panel] [artifact case]│",
      "│  docent whispers: \"read the label\" │",
      "│ [sculpture plinth] [bench] [map]    │",
      "│ galleries cross-talk across decades │",
      "╰─────────────────────────────────────╯"
    ]
  }
];

export const ZONE_LOOKUP = Object.fromEntries(ZONES.map((zone) => [zone.id, zone]));
