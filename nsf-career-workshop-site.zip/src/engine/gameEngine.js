import { BOOK_TOPICS, DUEL_MOVES, HARD_CODED_EVENTS, PROCEDURAL_ITEM_TYPES } from "../constants/gameplay";
import { NPC_BY_ID, NPCS } from "../constants/npcs";
import { PRIMARY_SOURCES } from "../constants/primarySources";
import {
  GAME_OVER_RULES,
  LEVEL_THRESHOLDS,
  STARTING_STATS,
  ZONES,
  ZONE_LOOKUP
} from "../constants/world";
import { chance, hashString, mulberry32, sample } from "../lib/rng";

const START_ZONE = "rowan-oak";

export function calculateLevelFromXp(xp) {
  let level = 1;
  for (let i = 0; i < LEVEL_THRESHOLDS.length; i += 1) {
    if (xp >= LEVEL_THRESHOLDS[i]) {
      level = i + 1;
    }
  }
  return level;
}

function getDayLabel(day, turn) {
  return `Day ${day}, Turn ${turn}`;
}

function getTurnSeed(state) {
  return hashString(`${state.seed}-${state.day}-${state.turn}-${state.zoneId}`);
}

function pickZoneNpc(zoneId) {
  const roster = NPCS.filter((npc) => npc.zoneId === zoneId);
  return roster[Math.floor(Math.random() * roster.length)] ?? null;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function rollForItem(state) {
  const rng = mulberry32(getTurnSeed(state));
  const baseType = sample(PROCEDURAL_ITEM_TYPES, rng);
  const year = 1890 + Math.floor(rng() * 66);
  const isBook = baseType === "book" || chance(0.18, rng);

  const bookName = `${sample([
    "County Memoranda",
    "Agrarian Notes",
    "Ledger Fragments",
    "Civic Pamphlet",
    "Rail and River Almanac",
    "Household Circular"
  ], rng)} (${year})`;

  return {
    id: `${state.day}-${state.turn}-${Math.floor(rng() * 9999)}`,
    type: isBook ? "book" : baseType,
    name: isBook ? bookName : `${baseType[0].toUpperCase()}${baseType.slice(1)} (${year})`,
    provenance: sample([
      "courthouse annex shelf",
      "gallery donation bin",
      "river landing crate",
      "estate desk drawer",
      "church office archive"
    ], rng),
    topic: sample(BOOK_TOPICS, rng),
    year,
    readable: isBook,
    generatedText: ""
  };
}

function maybeFindPrimarySource(state) {
  const rng = mulberry32(getTurnSeed(state) ^ 0x9e3779b9);
  const already = new Set(state.discoveredSources);
  const unseen = PRIMARY_SOURCES.filter((src) => !already.has(src.id));
  if (!unseen.length || !chance(0.42, rng)) return null;
  return sample(unseen, rng);
}

function appendLog(state, { type, message, meta }) {
  return {
    ...state,
    gameLog: [
      {
        id: `log-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
        day: state.day,
        dayLabel: getDayLabel(state.day, state.turn),
        type,
        message,
        meta: meta ?? null,
        createdAt: new Date().toISOString()
      },
      ...state.gameLog
    ]
  };
}

function appendTranscript(state, speaker, text, npcId = null) {
  const entry = {
    id: `tx-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    day: state.day,
    turn: state.turn,
    turnLabel: getDayLabel(state.day, state.turn),
    speaker,
    text,
    npcId,
    createdAt: new Date().toISOString()
  };

  const updatedDialogue = npcId
    ? {
        ...state.dialogueByNpc,
        [npcId]: [...(state.dialogueByNpc[npcId] ?? []), entry]
      }
    : state.dialogueByNpc;

  return {
    ...state,
    transcript: [...state.transcript, entry],
    dialogueByNpc: updatedDialogue
  };
}

function advanceTime(state, deltaTurns = 1) {
  const nextTurn = state.turn + deltaTurns;
  const dayShift = Math.floor((nextTurn - 1) / 5);
  return {
    ...state,
    turn: ((nextTurn - 1) % 5) + 1,
    day: state.day + dayShift,
    fatigue: state.fatigue + deltaTurns
  };
}

function applyProgress(state, { xp = 0, reputation = 0, suspicion = 0, scandal = 0, fatigue = 0, archive = 0 }) {
  const nextXp = Math.max(0, state.xp + xp);
  const nextLevel = calculateLevelFromXp(nextXp);
  return {
    ...state,
    xp: nextXp,
    level: nextLevel,
    reputation: state.reputation + reputation,
    suspicion: state.suspicion + suspicion,
    scandal: state.scandal + scandal,
    fatigue: state.fatigue + fatigue,
    archiveInsight: state.archiveInsight + archive
  };
}

function evaluateGameOver(state) {
  if (state.scandal >= GAME_OVER_RULES.scandalLimit) {
    return {
      reason: "Public Scandal",
      outcome:
        "A libel threat and two editorials end your campaign. You leave with notes, fewer friends, and excellent cautionary material."
    };
  }

  if (state.fatigue >= GAME_OVER_RULES.exhaustionLimit) {
    return {
      reason: "Exhaustion",
      outcome: "You collapse from overwork and rhetorical overreach. The county continues without your narration for a while."
    };
  }

  if (state.suspicion <= GAME_OVER_RULES.suspicionLimit) {
    return {
      reason: "Run Out of Town",
      outcome: "People stop answering your questions and start answering about you. Doors close."
    };
  }

  if (
    state.level >= GAME_OVER_RULES.prestigeWinLevel &&
    state.archiveInsight >= GAME_OVER_RULES.prestigeWinArchives
  ) {
    return {
      reason: "Manuscript Completed",
      outcome: "You synthesize record, rumor, and witness into a credible county chronicle."
    };
  }

  if (state.day > GAME_OVER_RULES.maxDays) {
    return {
      reason: "Term Ended",
      outcome: "The season changes and your grant runs out. The notebook is unfinished but valuable."
    };
  }

  return null;
}

function maybeQueueHardcodedEvent(state) {
  if (state.activeEvent) return state;
  const event = HARD_CODED_EVENTS.find((candidate) => candidate.trigger(state));
  if (!event) return state;
  return {
    ...state,
    activeEvent: {
      id: event.id,
      title: event.title,
      summary: event.summary,
      choices: event.choices,
      source: "hardcoded"
    }
  };
}

export function createInitialState(saved) {
  if (saved?.version === 1 && saved.state) {
    return saved.state;
  }

  let state = {
    version: 1,
    seed: Date.now(),
    day: 1,
    turn: 1,
    zoneId: START_ZONE,
    xp: 0,
    level: 1,
    ...STARTING_STATS,
    suspicion: 0,
    scandal: 0,
    fatigue: 0,
    archiveInsight: 0,
    inventory: [],
    discoveredSources: [],
    journalEntries: [],
    gameLog: [],
    transcript: [],
    dialogueByNpc: {},
    activeEvent: null,
    activeDuel: null,
    activeBook: null,
    assessment: null,
    gameOver: null,
    flags: {},
    minigameState: {
      active: false,
      index: 0,
      score: 0,
      completed: false
    },
    easterEggs: {
      fishQuoteUnlocked: false,
      moonClicks: 0,
      secretSeed: false
    }
  };

  state = appendLog(state, {
    type: "system",
    message: "Run initialized. You begin at Rowan Oak with a fresh notebook and dangerous confidence."
  });

  return state;
}

export function getZoneById(zoneId) {
  return ZONE_LOOKUP[zoneId] ?? ZONES[0];
}

export function moveToZone(state, targetZoneId) {
  if (state.gameOver) return state;
  if (state.zoneId === targetZoneId) return state;

  const current = getZoneById(state.zoneId);
  if (!current.neighbors.includes(targetZoneId)) {
    return appendLog(state, {
      type: "warning",
      message: "You cannot reach that zone directly from here."
    });
  }

  let next = {
    ...state,
    zoneId: targetZoneId,
    activeDuel: null,
    activeBook: null
  };

  next = advanceTime(next, 1);
  next = applyProgress(next, { xp: 10, fatigue: 0 });
  next = appendLog(next, {
    type: "travel",
    message: `Traveled to ${getZoneById(targetZoneId).name}.`
  });

  next = maybeQueueHardcodedEvent(next);
  const maybeOver = evaluateGameOver(next);
  if (maybeOver) {
    next = {
      ...next,
      gameOver: maybeOver
    };
    next = appendLog(next, {
      type: "gameover",
      message: `${maybeOver.reason}: ${maybeOver.outcome}`
    });
  }

  return next;
}

export function exploreZone(state) {
  if (state.gameOver) return state;

  const zone = getZoneById(state.zoneId);
  let next = advanceTime(state, 1);
  next = applyProgress(next, {
    xp: 14 + zone.risk * 2,
    archive: 1,
    suspicion: zone.risk > 3 ? 1 : 0
  });

  const item = rollForItem(next);
  next = {
    ...next,
    inventory: [item, ...next.inventory]
  };

  next = appendLog(next, {
    type: "explore",
    message: `Explored ${zone.name} and recovered ${item.name}.`,
    meta: { itemId: item.id }
  });

  const source = maybeFindPrimarySource(next);
  if (source) {
    next = {
      ...next,
      discoveredSources: [source.id, ...next.discoveredSources],
      archiveInsight: next.archiveInsight + 1
    };
    next = appendLog(next, {
      type: "source",
      message: `Found primary source: ${source.title} (${source.year}).`,
      meta: { sourceId: source.id }
    });
  }

  next = maybeQueueHardcodedEvent(next);
  const over = evaluateGameOver(next);
  if (over) {
    next = { ...next, gameOver: over };
    next = appendLog(next, { type: "gameover", message: `${over.reason}: ${over.outcome}` });
  }

  return next;
}

export function queueDynamicEvent(state, dynamicEvent) {
  if (state.activeEvent || state.gameOver || !dynamicEvent) return state;
  return {
    ...state,
    activeEvent: {
      ...dynamicEvent,
      source: "llm"
    }
  };
}

export function resolveActiveEventChoice(state, choiceIndex) {
  if (!state.activeEvent || state.gameOver) return state;
  const choice = state.activeEvent.choices?.[choiceIndex];
  if (!choice) return state;

  let next = applyProgress(state, {
    xp: choice.effects?.xp ?? 0,
    reputation: choice.effects?.reputation ?? 0,
    suspicion: choice.effects?.suspicion ?? 0,
    scandal: choice.effects?.scandal ?? 0,
    fatigue: choice.effects?.fatigue ?? 0,
    archive: choice.effects?.archive ?? 0
  });

  if (choice.effects?.flag) {
    next = {
      ...next,
      flags: {
        ...next.flags,
        [choice.effects.flag]: true
      }
    };
  }

  next = appendLog(next, {
    type: "event",
    message: `${next.activeEvent.title}: ${choice.result}`
  });

  next = {
    ...next,
    activeEvent: null
  };

  const over = evaluateGameOver(next);
  if (over) {
    next = { ...next, gameOver: over };
    next = appendLog(next, { type: "gameover", message: `${over.reason}: ${over.outcome}` });
  }

  return next;
}

export function addJournalEntry(state, text) {
  if (!text?.trim()) return state;

  const entry = {
    id: `jrnl-${Date.now()}`,
    day: state.day,
    zoneId: state.zoneId,
    text: text.trim(),
    createdAt: new Date().toISOString()
  };

  let next = {
    ...state,
    journalEntries: [entry, ...state.journalEntries]
  };

  if (text.toLowerCase().includes("my mother is a fish")) {
    next = {
      ...next,
      easterEggs: {
        ...next.easterEggs,
        fishQuoteUnlocked: true
      },
      inventory: [
        {
          id: `egg-fish-${Date.now()}`,
          type: "artifact",
          name: "Secret Sardine Tin (Unreasonably Canonical)",
          readable: false,
          provenance: "easter egg",
          year: 1930,
          topic: "inside joke"
        },
        ...next.inventory
      ]
    };
  }

  next = appendLog(next, {
    type: "journal",
    message: "Journal entry added."
  });

  return next;
}

export function removeInventoryItem(state, itemId) {
  return {
    ...state,
    inventory: state.inventory.filter((item) => item.id !== itemId)
  };
}

export function setBookText(state, itemId, textPayload) {
  return {
    ...state,
    inventory: state.inventory.map((item) =>
      item.id === itemId
        ? {
            ...item,
            generatedText: textPayload?.excerpt ?? "",
            authenticityNotes: textPayload?.authenticityNotes ?? "",
            textType: textPayload?.textType ?? "report"
          }
        : item
    ),
    activeBook: itemId
  };
}

export function closeBook(state) {
  return {
    ...state,
    activeBook: null
  };
}

export function startNpcDialogue(state, npcId, playerPrompt) {
  const npc = NPC_BY_ID[npcId] || pickZoneNpc(state.zoneId);
  if (!npc) return state;

  let next = appendTranscript(state, "You", playerPrompt, npc.id);
  next = appendLog(next, {
    type: "dialogue",
    message: `You approached ${npc.name}.`
  });

  return next;
}

export function appendNpcDialogue(state, npcId, utterance) {
  const npc = NPC_BY_ID[npcId];
  if (!npc) return state;
  let next = appendTranscript(state, npc.name, utterance, npc.id);
  next = appendLog(next, {
    type: "dialogue",
    message: `${npc.name}: ${utterance}`,
    meta: { npcId: npc.id }
  });
  next = applyProgress(next, { xp: 12, archive: 1 });
  return next;
}

export function startDuel(state, npcId) {
  if (state.activeDuel || state.gameOver) return state;
  const npc = NPC_BY_ID[npcId] || pickZoneNpc(state.zoneId);
  if (!npc) return state;

  let next = {
    ...state,
    activeDuel: {
      npcId: npc.id,
      npcComposure: 94,
      playerComposure: 100,
      round: 1,
      history: [],
      winner: null,
      loser: null
    }
  };

  next = appendLog(next, {
    type: "duel",
    message: `A battle of wits begins with ${npc.name}.`
  });

  return next;
}

function chooseNpcMove(npcId, rng) {
  const npc = NPC_BY_ID[npcId];
  if (!npc) return DUEL_MOVES[0];

  const favored = DUEL_MOVES.filter((move) => move.family === npc.combatBias);
  if (favored.length && chance(0.62, rng)) {
    return sample(favored, rng);
  }
  return sample(DUEL_MOVES, rng);
}

export function playDuelMove(state, moveId) {
  if (!state.activeDuel || state.gameOver) return state;

  const duel = state.activeDuel;
  const npc = NPC_BY_ID[duel.npcId];
  const move = DUEL_MOVES.find((candidate) => candidate.id === moveId) ?? DUEL_MOVES[0];
  const rng = mulberry32(getTurnSeed(state) ^ duel.round);

  const playerHit = chance(move.accuracy, rng);
  const npcMove = chooseNpcMove(duel.npcId, rng);
  const npcHit = chance(npcMove.accuracy, rng);

  const playerDamage = playerHit ? Math.round(move.power + state.wit * 1.8 + state.level * 1.4 + rng() * 6) : 0;
  const npcDamage = npcHit ? Math.round(npcMove.power + 7 + rng() * 7) : 0;

  const nextNpcComposure = clamp(duel.npcComposure - playerDamage, 0, 120);
  const nextPlayerComposure = clamp(duel.playerComposure - npcDamage, 0, 120);

  const historyEntry = {
    round: duel.round,
    playerMove: move,
    npcMove,
    playerDamage,
    npcDamage,
    playerHit,
    npcHit
  };

  let next = {
    ...state,
    activeDuel: {
      ...duel,
      npcComposure: nextNpcComposure,
      playerComposure: nextPlayerComposure,
      round: duel.round + 1,
      history: [historyEntry, ...duel.history]
    }
  };

  next = appendLog(next, {
    type: "duel",
    message: `${move.name} dealt ${playerDamage}. ${npcMove.name} dealt ${npcDamage}.`
  });

  if (nextNpcComposure === 0 || nextPlayerComposure === 0) {
    const playerWon = nextNpcComposure === 0 && nextPlayerComposure > 0;
    const winner = playerWon ? "player" : "npc";

    next = {
      ...next,
      activeDuel: {
        ...next.activeDuel,
        winner,
        loser: playerWon ? npc.id : "player"
      }
    };

    next = applyProgress(next, {
      xp: playerWon ? 44 : 12,
      reputation: playerWon ? 2 : -1,
      suspicion: playerWon ? -1 : 1,
      scandal: playerWon ? 0 : 1,
      fatigue: 1,
      archive: playerWon ? 2 : 0
    });

    next = appendLog(next, {
      type: "duel-result",
      message: playerWon
        ? `You outmaneuvered ${npc.name} in public conversation. The square pretends not to be impressed.`
        : `${npc.name} dismantled your argument. The county will remember that sentence for months.`
    });

    next = {
      ...next,
      activeDuel: null
    };

    const over = evaluateGameOver(next);
    if (over) {
      next = { ...next, gameOver: over };
      next = appendLog(next, { type: "gameover", message: `${over.reason}: ${over.outcome}` });
    }
  }

  return next;
}

export function runMoonClick(state) {
  return {
    ...state,
    easterEggs: {
      ...state.easterEggs,
      moonClicks: state.easterEggs.moonClicks + 1,
      secretSeed: state.easterEggs.moonClicks + 1 >= 5
    }
  };
}

export function getVisiblePrimarySources(state) {
  if (!state.discoveredSources.length) {
    return PRIMARY_SOURCES.slice(0, 2);
  }

  const discovered = new Set(state.discoveredSources);
  return PRIMARY_SOURCES.filter((source) => discovered.has(source.id));
}

export function deriveAssessmentMetrics(state) {
  const sourceWeight = Math.min(10, getVisiblePrimarySources(state).length);
  const levelWeight = Math.min(15, state.level * 2);
  const journalWeight = Math.min(12, state.journalEntries.length * 2);
  const reputationWeight = clamp(8 + state.reputation, 0, 18);
  const dialogueWeight = Math.min(10, Math.floor(state.transcript.length / 3));

  return {
    sourceWeight,
    levelWeight,
    journalWeight,
    reputationWeight,
    dialogueWeight
  };
}

export function digestForAssessment(state) {
  const journalDigest = state.journalEntries
    .slice(0, 5)
    .map((entry) => `${entry.day}/${entry.zoneId}: ${entry.text.slice(0, 120)}`)
    .join(" | ");

  const logDigest = state.gameLog
    .slice(0, 8)
    .map((entry) => `${entry.type}:${entry.message.slice(0, 90)}`)
    .join(" | ");

  const dialogueDigest = state.transcript
    .slice(-12)
    .map((entry) => `${entry.speaker}: ${entry.text.slice(0, 80)}`)
    .join(" | ");

  return { journalDigest, logDigest, dialogueDigest };
}

export function listAvailableNpcsForZone(zoneId) {
  return NPCS.filter((npc) => npc.zoneId === zoneId);
}

export function listNeighborZones(zoneId) {
  return (getZoneById(zoneId).neighbors ?? []).map((id) => getZoneById(id));
}
