import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MINIGAME_QUESTIONS } from "../constants/gameplay";
import { NPC_BY_ID } from "../constants/npcs";
import { GALLERY_RESEARCH_NOTES } from "../constants/galleryData";
import {
  addJournalEntry,
  appendNpcDialogue,
  calculateLevelFromXp,
  closeBook,
  createInitialState,
  deriveAssessmentMetrics,
  digestForAssessment,
  exploreZone,
  getVisiblePrimarySources,
  getZoneById,
  listAvailableNpcsForZone,
  listNeighborZones,
  moveToZone,
  playDuelMove,
  queueDynamicEvent,
  resolveActiveEventChoice,
  runMoonClick,
  setBookText,
  startDuel,
  startNpcDialogue
} from "./gameEngine";
import { clearSavedGame, loadGameFromStorage, saveGameToStorage } from "../lib/persistence";
import { exportTranscriptAsJson, exportTranscriptAsMarkdown } from "../lib/exporters";
import { generateAssessment, generateBookText, generateDynamicEvent, generateFactCheck, generateNpcReply } from "../lib/llm/adapters";
import { fetchWikipediaSummary } from "../lib/wikipedia";

const defaultPreferences = {
  theme: "light",
  animationLevel: "normal",
  asciiGlow: true,
  autoFactCheck: false,
  wikiIntegration: true,
  difficulty: "standard",
  llm: {
    enabled: false,
    apiKey: "",
    model: "gpt-5-mini"
  }
};

export function useGameEngine() {
  const saved = useMemo(() => loadGameFromStorage(), []);
  const [state, setState] = useState(() => createInitialState(saved));
  const [preferences, setPreferences] = useState(() => ({
    ...defaultPreferences,
    ...(saved?.preferences ?? {})
  }));
  const [busy, setBusy] = useState({
    npc: false,
    event: false,
    book: false,
    assessment: false,
    factCheck: false
  });
  const [factCheckResult, setFactCheckResult] = useState(null);

  const stateRef = useRef(state);
  const preferencesRef = useRef(preferences);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    preferencesRef.current = preferences;
  }, [preferences]);

  useEffect(() => {
    saveGameToStorage({
      version: 1,
      savedAt: new Date().toISOString(),
      state,
      preferences
    });
  }, [state, preferences]);

  const commit = useCallback((updater) => {
    setState((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      stateRef.current = next;
      return next;
    });
  }, []);

  const getLlmConfig = () => preferencesRef.current.llm;

  const buildPromptState = useCallback((snapshot) => {
    const zone = getZoneById(snapshot.zoneId);
    return {
      day: snapshot.day,
      level: snapshot.level,
      xp: snapshot.xp,
      reputation: snapshot.reputation,
      suspicion: snapshot.suspicion,
      scandal: snapshot.scandal,
      zoneName: zone.name,
      recentLog: snapshot.gameLog.slice(0, 6).map((entry) => entry.message),
      recentLogTypes: snapshot.gameLog.slice(0, 6).map((entry) => entry.type)
    };
  }, []);

  const maybeSpawnDynamicEvent = useCallback(async (baseState) => {
    if (baseState.gameOver || baseState.activeEvent || Math.random() > 0.35) {
      return;
    }

    setBusy((prev) => ({ ...prev, event: true }));
    const zone = getZoneById(baseState.zoneId);
    const event = await generateDynamicEvent({
      config: getLlmConfig(),
      state: buildPromptState(baseState),
      zone,
      recentTranscript: baseState.transcript.slice(-5).map((line) => `${line.speaker}: ${line.text}`)
    });

    commit((prev) => queueDynamicEvent(prev, event));
    setBusy((prev) => ({ ...prev, event: false }));
  }, [buildPromptState, commit]);

  const travelToZone = useCallback(async (zoneId) => {
    let next = null;
    commit((prev) => {
      next = moveToZone(prev, zoneId);
      return next;
    });

    if (next) {
      await maybeSpawnDynamicEvent(next);
    }
  }, [commit, maybeSpawnDynamicEvent]);

  const explore = useCallback(async () => {
    let next = null;
    commit((prev) => {
      next = exploreZone(prev);
      return next;
    });

    if (next) {
      await maybeSpawnDynamicEvent(next);
    }
  }, [commit, maybeSpawnDynamicEvent]);

  const talkToNpc = useCallback(async (npcId, playerInput) => {
    if (!playerInput?.trim()) return;

    const npc = NPC_BY_ID[npcId];
    if (!npc) return;

    commit((prev) => {
      return startNpcDialogue(prev, npc.id, playerInput.trim());
    });

    setBusy((prev) => ({ ...prev, npc: true }));

    const snapshot = stateRef.current;
    const reply = await generateNpcReply({
      config: getLlmConfig(),
      npc,
      state: buildPromptState(snapshot),
      playerInput,
      memorySlice: (snapshot.dialogueByNpc[npc.id] ?? []).slice(-4).map((line) => line.text)
    });

    commit((prev) => appendNpcDialogue(prev, npc.id, reply.utterance));
    setBusy((prev) => ({ ...prev, npc: false }));

    if (preferencesRef.current.autoFactCheck) {
      await requestFactCheck(reply.utterance);
    }

    await maybeSpawnDynamicEvent(stateRef.current);
  }, [buildPromptState, commit, maybeSpawnDynamicEvent]);

  const openBook = useCallback(async (itemId) => {
    const item = stateRef.current.inventory.find((entry) => entry.id === itemId);
    if (!item || !item.readable) return;

    if (item.generatedText) {
      commit((prev) => ({ ...prev, activeBook: itemId }));
      return;
    }

    setBusy((prev) => ({ ...prev, book: true }));
    const excerpt = await generateBookText({
      config: getLlmConfig(),
      item,
      state: buildPromptState(stateRef.current)
    });

    commit((prev) => setBookText(prev, itemId, excerpt));
    setBusy((prev) => ({ ...prev, book: false }));
  }, [buildPromptState, commit]);

  const closeOpenBook = useCallback(() => {
    commit((prev) => closeBook(prev));
  }, [commit]);

  const chooseEventOption = useCallback((index) => {
    commit((prev) => resolveActiveEventChoice(prev, index));
  }, [commit]);

  const beginDuel = useCallback((npcId) => {
    commit((prev) => startDuel(prev, npcId));
  }, [commit]);

  const playDuelRound = useCallback((moveId) => {
    commit((prev) => playDuelMove(prev, moveId));
  }, [commit]);

  const addJournal = useCallback((text) => {
    commit((prev) => addJournalEntry(prev, text));
  }, [commit]);

  const runAssessment = useCallback(async () => {
    const snapshot = stateRef.current;
    const metrics = deriveAssessmentMetrics(snapshot);
    const digests = digestForAssessment(snapshot);

    setBusy((prev) => ({ ...prev, assessment: true }));

    const assessment = await generateAssessment({
      config: getLlmConfig(),
      state: {
        ...buildPromptState(snapshot),
        gameOver: snapshot.gameOver,
        journalDigest: digests.journalDigest,
        logDigest: digests.logDigest,
        dialogueDigest: digests.dialogueDigest
      },
      derivedMetrics: metrics
    });

    commit((prev) => ({
      ...prev,
      assessment,
      gameLog: [
        {
          id: `log-assess-${Date.now()}`,
          day: prev.day,
          dayLabel: `Day ${prev.day}, Turn ${prev.turn}`,
          type: "assessment",
          message: `Assessment score ${assessment.score}: ${assessment.summary}`,
          createdAt: new Date().toISOString()
        },
        ...prev.gameLog
      ]
    }));

    setBusy((prev) => ({ ...prev, assessment: false }));
  }, [buildPromptState, commit]);

  const requestFactCheck = useCallback(async (claim) => {
    if (!claim?.trim()) return;

    const snapshot = stateRef.current;
    setBusy((prev) => ({ ...prev, factCheck: true }));

    const analysis = await generateFactCheck({
      config: getLlmConfig(),
      claim,
      state: buildPromptState(snapshot),
      primarySources: getVisiblePrimarySources(snapshot)
    });

    let wiki = null;
    if (preferencesRef.current.wikiIntegration && analysis.wikipediaTopic) {
      wiki = await fetchWikipediaSummary(analysis.wikipediaTopic);
    }

    setFactCheckResult({
      claim,
      analysis,
      wiki,
      checkedAt: new Date().toISOString()
    });

    setBusy((prev) => ({ ...prev, factCheck: false }));
  }, [buildPromptState]);

  const startMinigame = useCallback(() => {
    commit((prev) => ({
      ...prev,
      minigameState: {
        active: true,
        index: 0,
        score: 0,
        completed: false,
        feedback: ""
      }
    }));
  }, [commit]);

  const answerMinigame = useCallback((choiceIndex) => {
    commit((prev) => {
      const mg = prev.minigameState;
      if (!mg.active || mg.completed) return prev;

      const question = MINIGAME_QUESTIONS[mg.index];
      const correct = question.answerIndex === choiceIndex;
      const nextScore = mg.score + (correct ? 1 : 0);
      const nextIndex = mg.index + 1;
      const complete = nextIndex >= MINIGAME_QUESTIONS.length;

      const nextState = {
        ...prev,
        minigameState: {
          active: true,
          index: complete ? mg.index : nextIndex,
          score: nextScore,
          completed: complete,
          feedback: `${correct ? "Correct" : "Not quite"}: ${question.rationale}`
        },
        xp: prev.xp + (correct ? 10 : 4)
      };

      if (complete) {
        nextState.level = Math.max(prev.level, Math.floor((nextState.xp + 80) / 120));
        nextState.gameLog = [
          {
            id: `log-minigame-${Date.now()}`,
            day: prev.day,
            dayLabel: `Day ${prev.day}, Turn ${prev.turn}`,
            type: "minigame",
            message: `Archive Sprint complete: ${nextScore}/${MINIGAME_QUESTIONS.length}`,
            createdAt: new Date().toISOString()
          },
          ...prev.gameLog
        ];
      }

      return nextState;
    });
  }, [commit]);

  const closeMinigame = useCallback(() => {
    commit((prev) => ({
      ...prev,
      minigameState: {
        ...prev.minigameState,
        active: false
      }
    }));
  }, [commit]);

  const updatePreferences = useCallback((patch) => {
    setPreferences((prev) => ({
      ...prev,
      ...patch,
      llm: {
        ...prev.llm,
        ...(patch.llm ?? {})
      }
    }));
  }, []);

  const clickMoon = useCallback(() => {
    commit((prev) => runMoonClick(prev));
  }, [commit]);

  const saveNow = useCallback(() => {
    saveGameToStorage({
      version: 1,
      savedAt: new Date().toISOString(),
      state: stateRef.current,
      preferences: preferencesRef.current
    });
  }, []);

  const resetRun = useCallback(() => {
    clearSavedGame();
    commit(createInitialState());
    setFactCheckResult(null);
  }, [commit]);

  const debugGrantXp = useCallback(() => {
    commit((prev) => {
      const xp = prev.xp + 150;
      return {
        ...prev,
        xp,
        level: calculateLevelFromXp(xp),
        gameLog: [
          {
            id: `log-debug-xp-${Date.now()}`,
            day: prev.day,
            dayLabel: `Day ${prev.day}, Turn ${prev.turn}`,
            type: "debug",
            message: "Debug: granted 150 XP.",
            createdAt: new Date().toISOString()
          },
          ...prev.gameLog
        ]
      };
    });
  }, [commit]);

  const debugForceEvent = useCallback(() => {
    commit((prev) => ({
      ...prev,
      activeEvent: {
        title: "Debug Event: Editorial Deadline",
        summary: "A local editor asks you to publish an unverified claim before noon.",
        source: "debug",
        choices: [
          {
            text: "Publish now and verify later.",
            result: "The story spreads faster than corrections ever do.",
            effects: { xp: 10, reputation: -1, scandal: 1, suspicion: 1 }
          },
          {
            text: "Delay publication until one source is confirmed.",
            result: "You lose the scoop and keep your integrity mostly intact.",
            effects: { xp: 14, reputation: 1, scandal: 0, suspicion: -1 }
          },
          {
            text: "Refuse and write a methods piece instead.",
            result: "Nobody calls it exciting, but your notes age better than rumors.",
            effects: { xp: 18, reputation: 1, archive: 1 }
          }
        ]
      }
    }));
  }, [commit]);

  const debugForceGameOver = useCallback(() => {
    commit((prev) => ({
      ...prev,
      gameOver: {
        reason: "Debug Outcome",
        outcome: "Forced terminal state for testing assessment and end screens."
      }
    }));
  }, [commit]);

  const exportJson = useCallback(() => {
    exportTranscriptAsJson(stateRef.current);
  }, []);

  const exportMarkdown = useCallback(() => {
    exportTranscriptAsMarkdown(stateRef.current);
  }, []);

  const zone = getZoneById(state.zoneId);
  const neighbors = listNeighborZones(state.zoneId);
  const zoneNpcs = listAvailableNpcsForZone(state.zoneId);
  const primarySources = getVisiblePrimarySources(state);

  return {
    state,
    preferences,
    busy,
    factCheckResult,
    zone,
    neighbors,
    zoneNpcs,
    primarySources,
    galleryResearch: GALLERY_RESEARCH_NOTES,
    minigameQuestions: MINIGAME_QUESTIONS,
    actions: {
      travelToZone,
      explore,
      talkToNpc,
      openBook,
      closeOpenBook,
      chooseEventOption,
      beginDuel,
      playDuelRound,
      addJournal,
      runAssessment,
      requestFactCheck,
      startMinigame,
      answerMinigame,
      closeMinigame,
      updatePreferences,
      clickMoon,
      saveNow,
      resetRun,
      debugGrantXp,
      debugForceEvent,
      debugForceGameOver,
      exportJson,
      exportMarkdown
    }
  };
}
