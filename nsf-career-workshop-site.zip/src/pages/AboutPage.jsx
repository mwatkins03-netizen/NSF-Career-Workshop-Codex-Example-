import { ABOUT_MARKDOWN } from "../constants/content";
import Panel from "../components/Panel";

function renderMarkdownLine(line, index) {
  if (line.startsWith("# ")) {
    return (
      <h2 key={index} className="font-display text-2xl font-semibold">
        {line.slice(2)}
      </h2>
    );
  }

  if (line.startsWith("## ")) {
    return (
      <h3 key={index} className="mt-4 font-display text-lg font-semibold">
        {line.slice(3)}
      </h3>
    );
  }

  if (line.startsWith("- ")) {
    return (
      <li key={index} className="ml-5 list-disc text-sm leading-relaxed">
        {line.slice(2)}
      </li>
    );
  }

  if (!line.trim()) return <div key={index} className="h-2" />;

  const boldPattern = /\*\*(.*?)\*\*/g;
  const segments = [];
  let lastIndex = 0;
  let match;

  while ((match = boldPattern.exec(line)) !== null) {
    if (match.index > lastIndex) {
      segments.push(line.slice(lastIndex, match.index));
    }
    segments.push(<strong key={`${index}-${match.index}`}>{match[1]}</strong>);
    lastIndex = match.index + match[0].length;
  }

  if (lastIndex < line.length) {
    segments.push(line.slice(lastIndex));
  }

  return (
    <p key={index} className="text-sm leading-relaxed text-zinc-700 dark:text-zinc-200">
      {segments.length ? segments : line}
    </p>
  );
}

export default function AboutPage() {
  return (
    <Panel title="About" subtitle="Design intent, educational scope, and historical framing">
      <div className="space-y-1">{ABOUT_MARKDOWN.trim().split("\n").map(renderMarkdownLine)}</div>
    </Panel>
  );
}
