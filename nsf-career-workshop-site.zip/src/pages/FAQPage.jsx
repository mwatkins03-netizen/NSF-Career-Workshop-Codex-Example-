import Panel from "../components/Panel";
import { FAQ_ITEMS } from "../constants/content";

export default function FAQPage() {
  return (
    <Panel title="FAQ" subtitle="How systems work and what is historically grounded">
      <div className="space-y-3">
        {FAQ_ITEMS.map((item) => (
          <article
            key={item.q}
            className="rounded-xl border border-black/10 bg-white/85 p-3 text-sm dark:border-white/15 dark:bg-zinc-800/80"
          >
            <h3 className="mb-1 font-semibold text-zinc-900 dark:text-zinc-100">{item.q}</h3>
            <p className="text-zinc-700 dark:text-zinc-200">{item.a}</p>
          </article>
        ))}
      </div>
    </Panel>
  );
}
